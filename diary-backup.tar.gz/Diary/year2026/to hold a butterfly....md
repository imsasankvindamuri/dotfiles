---
started: 8 Jan 2026, ~0200 hrs
feeling: tired
---
Welcome back, future wifey. I hope you're doing well. Grab yourself a coffee, OK? I wanna talk.

I once heard this beautiful quote, you know?

> If you want to hold a butterfly, don't chase it: it will only fly away. Build a beautiful garden instead, and it will come to you. And if it doesn't, you still have a beautiful garden.

Insight works like that, no? Chasing insight will lead you to frustration, but be calm and focus on learning, and you will gain insight naturally. We all chase the grace of Sarasvati Amma, that one beautiful insight to revolutionize our life, but it doesn't work that way, does it?

I don't remember where I was going with this train of thought, but... I have something cool to share. This deals with calculus, but in a beautifully geometric way, but even so: if you have anxiety about calculus, feel free to sit this one out.

---

I've always been frustrated by the below integral, you know?

$$
\int_{\mathbb{R}} \frac{dx}{1 + x^2} = \pi
$$

It feels so... arbitrary. Like the thing dropped from the sky or something. The way this is explained in calculus class is very dry, you know? It goes like this: "*Ahem.* We're integrating over $\mathbb{R}$, the open interval $(-\infty, \infty)$. Let $x = \tan(\theta)$. Then, $dx = \sec^2(\theta) d\theta$. As $x \to -\infty$, $\theta \to -\frac{\pi}{2}$. Similarly, as $x \to \infty$, $\theta \to \frac{\pi}{2}$. Therefore, we have the below simplification."

$$
\begin{align*}
\int_{\mathbb{R}} \frac{dx}{1 + x^2} &=
\int_{-\frac{\pi}{2}}^{\frac{\pi}{2}} \frac{\sec^2(\theta)}{1 + \tan^2(\theta)} d\theta \\
&= \int_{-\frac{\pi}{2}}^{\frac{\pi}{2}} \frac{\sec^2(\theta)}{\sec^2(\theta)} d\theta \\
&= \int_{-\frac{\pi}{2}}^{\frac{\pi}{2}} d\theta = \frac{\pi}{2} - \left( -\frac{\pi}{2} \right) \\
&= \pi
\tag*{$\mathfrak{Q.E.D.}$}
\end{align*}
$$

Wow... That was... something, no? It felt like just a bunch of symbol juggling, and you'd be forgiven for walking away with the impression that $\pi$ "just appears outta nowhere" and that mathematics is nothing more than "manipulation of symbols as per arbitrary rules," you know?

(Looking straight at you, David Hilbert, Nicholas Bourbaki, and the entire formalist school. I blame all of you for creating a generation of students who see mathematics as torture.)

But this is obvious yabberjack! Mathematics arises from the mind, sure. But she rises from the world itself. If something "doesn't make sense" in mathematics, it just means that you're not looking hard enough. Fortunately, I have found a beautiful, visual proof of this integral which I would like to share.

Let's begin.

---

### Question

Prove that

$$
\int_{\mathbb{R}} \frac{dx}{1 + x^2} = \pi
$$

**Intuition:**

The basic idea is the following: we will attempt to "rectify" the arc length. That is, we will try to convert curved motion to straight-line motion. This is something we saw in the method of exhaustion in [[little steps + persistence = beauty]].

To explain in a very high-level way: imagine a circle and a tangent line like so:

<p style="text-align:center;">
	<img src="./note_resources/circle-and-tangent.svg" /> 
	<strong>A Circle and its Tangent</strong>
</p>

Now, imagine you are on the circle's centre and I am on the tangent, and I am running along the whole length of the tangent while you try to keep your eyes fixed on me. As I run from $-\infty$ to $\infty$, i.e., as I run along the tangent, your head has to sweep out $180 \degree$, and the arc length of $180 \degree$ is $\pi$.

That's it. That's what the integral is saying. All that really remains is to tighten up some logic, but in essence, when I say...

$$
\int_{\mathbb{R}} \frac{dx}{1 + x^2} = \pi
$$

... what I mean is "the arc length swept out by a point moving along a circle's tangent is equal to $\pi$", which seems blindingly obvious all of a sudden, no?

Of course, we need to sharpen out details, and they are equally beautiful, so let us get to them.

**Proof:**

Let us imagine a point on the tangent that moves from $-\infty$ to $\infty$. We'll need to rigorously calculate the arc swept out by it. The idea is that we will analyze the small arc $\delta \theta$ swept out by a small step $\delta u$ along the tangent. The summation of all the $\delta \theta$s will be $\pi$ due to the earlier arc-length observation, so what we are betting on is that the small arc length is related in some way to the small step $\delta u$ that leads us back to the integral.

<p style="text-align:center;">
	<img src="./note_resources/pi-tangent-proof.svg" /> 
	<strong>A Small Step on the Tangent</strong>
</p>

I know the above diagram looks a bit scary, but please: allow me to demystify it.

- We have a circle with radius $\mathrm{OA} = 1$, and we have a tangent line $\mathrm{AR}$. In this diagram, it goes infinitely in one direction, but that is simply to keep things focused. The real tangent extends infinitely in both directions.
- We have traversed a length $\mathrm{PA} = u$ along the tangent, and it "subtends" an angle $\angle \mathrm{YOA} = \theta$ inside the circle. That is to say, your head had to sweep an arc of $\theta$ from dead-centre to look at that point. Also, we have dropped a small perpendicular $\mathrm{YX}$ as it will make our lives easier in the future.
- We consider a tiny length $\mathrm{RP} = \delta u$ along the tangent, which adds a small angle $\angle \mathrm{ZOY} = \delta \theta$ to our existing $\angle \mathrm{YOA}$. We have also connected $\mathrm{ZY}$, although that might be a tiny bit harder to notice here. (That difficulty is actually the core of the argument! As $\delta u$ becomes as small as you like, the tiny arc length $\delta s = r \cdot \delta \theta = 1 \cdot \delta \theta = \delta \theta$ looks like a straight line.)
- We also have the weird construction line $\mathrm{PQ}$ where $\mathrm{PQ \parallel ZY}$.

Now, look at $\triangle \mathrm{OZY}$ and $\triangle \mathrm{OPQ}$. Since $\mathrm{PQ \parallel ZY}$, we automatically have that $\mathrm{\angle OZY = \angle OQP}$ and $\mathrm{\angle OYZ = \angle OPQ}$. Therefore, $\mathrm{\triangle OZY \sim \triangle OPQ}$. So,

$$
\begin{align*}
\mathrm{\frac{OY}{ZY}} &= \mathrm{\frac{OP}{PQ}}\\
\implies \mathrm{\frac{1}{ZY}} &= \mathrm{\frac{1^2 + AP^2}{PQ}}\\
&= \frac{\sqrt{1 + u^2}}{\mathrm{PQ}}
\tag{Pyth. Thm on $\triangle \mathrm{OPA}$}\\
\implies \mathrm{ZY} &= \frac{\mathrm{PQ}}{\sqrt{1 + u^2}}
\tag{1}
\end{align*}
$$

As I mentioned earlier, we're going to use the fact that as $\delta u \to 0$, the arc $\mathrm{\overset{\frown}{ZY}}$ is approximated by the chord $\mathrm{ZY}$. Therefore:

$$
\begin{align*}
\mathrm{\overset{\frown}{ZY}} &\mathrel{\overset{\delta u \to 0}{=}} \mathrm{ZY} = \frac{\mathrm{PQ}}{\sqrt{1 + u^2}}\\
\implies \delta \theta &\mathrel{\overset{\delta u \to 0}{=}} \frac{\mathrm{PQ}}{\sqrt{1 + u^2}}
\tag{2}
\end{align*}
$$

Perfect. Now, we will compare $\mathrm{\triangle PQR}$ and $\mathrm{\triangle OXY}$. Now, we can do some angle chasing:

- $\mathrm{\angle OQP = \angle OPQ = \frac{\pi - \delta \theta}{2}}$ via some work with the 5th Postulate. Therefore, $\mathrm{\angle PQR = \pi - \frac{\pi - \delta \theta}{2} = \frac{\pi + \delta \theta}{2}}$.
- Applying the 5th Postulate to $\mathrm{\triangle ORA}$, we get that $\mathrm{\angle QRP = \frac{\pi}{2} - (\theta + \delta \theta)}$.

Note, then, that $\mathrm{\angle PQR \mathrel{\overset{\delta u \to 0}{=}} \frac{\pi}{2}}$ and that $\mathrm{\angle QRP \mathrel{\overset{\delta u \to 0}{=}} \frac{\pi}{2} - \theta}$. So, $\mathrm{\triangle OPA \mathrel{\overset{\delta u \to 0}{\sim}} \triangle PQR}$.

In smaller words, as $\delta u$ becomes tiny, $\mathrm{\triangle PQR}$ looks like $\mathrm{\triangle OPA}$.

(This is the part that trips most people up, you know? You can literally see it, but to make it official, you need to jump through hoops. Hell, I struggled to formalize this quite a bit, even though I had the insight. What you're seeing above is Draft #3.

What people don't see, and what Bourbaki and the Formalists drilled into modern students, is that this hoop-jumping is an acquired skill and *isn't true mathematics.* The true mathematics is the problem solving, the intuition, the creative and beautiful leaps and bounds that reveal structure in chaos.

Anyway, rant over.)

Now, since $\mathrm{\triangle OPA \mathrel{\overset{\delta u \to 0}{\sim}} \triangle PQR}$,

$$
\begin{align*}
\mathrm{\frac{OP}{OA}} &\mathrel{\overset{\delta u \to 0}{=}} \mathrm{\frac{RP}{PQ}}\\
\implies \frac{\sqrt{1 + u^2}}{1} &\mathrel{\overset{\delta u \to 0}{=}} \frac{\delta u}{\mathrm{PQ}}\\
\implies \mathrm{PQ} &\mathrel{\overset{\delta u \to 0}{=}} \frac{\delta u}{\sqrt{1 + u^2}}
\tag{3}
\end{align*}
$$

We're now gonna combine Eqn. 2 and Eqn. 3.

$$
\begin{align*}
\delta \theta &\mathrel{\overset{\delta u \to 0}{=}} \frac{\mathrm{PQ}}{\sqrt{1 + u^2}}\\
&\mathrel{\overset{\delta u \to 0}{=}} \frac{\delta u}{\sqrt{1 + u^2}} \cdot
\frac{1}{\sqrt{1 + u^2}}\\
\implies \delta \theta &\mathrel{\overset{\delta u \to 0}{=}} \frac{\delta u}{1 + u^2}
\tag{4}
\end{align*}
$$

So, we have related the small arc length to the small change in the position of the moving point. So now, if we sum over all small angles, we get this:

$$
\sum_{N} \delta \theta \mathrel{\overset{\delta u \to 0}{=}} \sum_{N} \frac{\delta u}{1 + u^2}\\
$$

As $\delta u \to 0$, the summation turns to integration, and the bounds go along the entire tangent line, i.e, from $-\infty$ to $\infty$. At the same time, we know that the $\mathfrak{LHS}$ is measuring the arc swept out by your head as you track the point moving along the tangent, which is just $\text{arc length of } 180 \degree = \pi$. As such, we can conclude that

$$
\int_{-\infty}^{\infty} \frac{du}{1 + u^2} = \pi
$$

Integration over $\mathbb{R}$ is just a fancier (and in my opinion, cleaner) way to indicate an integration from $-\infty$ to $\infty$, and that gives us our final answer.

$$
\int_{\mathbb{R}} \frac{dx}{1 + x^2} = \pi
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

You may have noticed that I constructed $\mathrm{XY}$ and proceeded to never use it. I only realized that after writing this.

Welp. Guess that's one thing in the rough draft that made it in. I'll keep it.

The above proof is actually very similar to reconstructed proofs of the great Indian Mathematician Madhava of Sangamagrama. I'm very proud of coming up with this same line of reasoning. It cheered me up after a painful day of spiraling. I loved it so much that I designed a picture with this construction and set it as my wallpaper.

Also, my therapist has suggested that I might be neurodivergent. That's right, wifey. You married an autistic freak, although you probably could tell that from all of my idiosyncrasies.

I mean, it's just a state of mind, no? I don't think it's a mental illness. Sarasvati Amma took away a few features from me, but blessed me with other gifts that some would die for. I'm happy with that trade.