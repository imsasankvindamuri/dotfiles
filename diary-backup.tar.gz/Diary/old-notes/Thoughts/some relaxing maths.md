---
title: some relaxing maths
updated: 2025-11-29 06:17:41Z
created: 2025-11-23 10:02:07Z
latitude: 18.98328290
longitude: 73.10849100
altitude: 0.0000
---

Heya, future wifey, anthropology major analyzing my diary, and future therapist.

I haven't been writing in this journal recently. Too burnt out. So I'll make this place a mental "save point": a place where I can retreat and feel good. I have my friends, my family, and so many beautiful people that Mother Sarasvati blessed me with, but I want to make this a small, cozy place, just for us four.

Yes, all of you are cordially invited to see me feel happy, joyful, and safe instead of watching me spiral about my childhood porn trauma or my job prospects or how I was forced into CS rather than maths or my obsessive pain to "prove" the existence of Brahman (even though it is foolish to use the laws of the world to prove the existence of something that transcends the world) or anything else. For just a few minutes, put on some calm music, forget about your work, and just let the world of austere logic comfort you with its elegant simplicity.

I'll just be doing some easy math problems without much complex machinery so that anyone can follow, and I'll keep my explanations down-to earth.

(Well, easy is always relative with me, isn't it? We'll see.)

---

### Question

Define

$$
H_n = 1 + \frac12 + \frac13 + ... + \frac1n
$$

Prove that

$$
H_{2n} - H_n \ge \frac12
$$

**Proof:**

Note that for all $0 \le k \le n$, $n+k \le 2n$. So, $\frac1{n+k} \ge \frac1{2n}$. Therefore:

$$
\begin{aligned}
H_{2n} - H_n &= \frac1{n+1} + \frac1{n+2} + \frac1{n+3} + \cdots + \frac1{2n}\\
&\ge \frac1{2n} + \frac1{2n} + \frac1{2n} + \cdots + \frac1{2n}\\
&= \frac12
\end{aligned}
$$

So:

$$
\begin{align*}
H_{2n} - H_n \ge \frac12
\tag*{$\mathfrak{Q.E.D.}$}
\end{align*}
$$

**Fun Fact:**

The harmonic number $H_n$ is known to satisfy:

$$
H_n = \ln n + \gamma + \varepsilon_n
$$

where $\gamma$ is the Euler-Mascheroni constant and $\varepsilon_n \to 0$ as $n \to \infty$. As such, in the case of $H_{2n} - H_n$ for large $n$:

$$
\begin{aligned}
H_{2n} - H_n &\approx (\ln(2n) + \gamma) - (\ln n + \gamma) \\
&= \ln(2n) - \ln n \\
&= \ln\left(\frac{2n}{n}\right) \\
&= \ln 2
\end{aligned}
$$

So indeed:

$$
\lim_{n \to \infty} (H_{2n} - H_n) = \ln 2 \approx 0.693147... \ge \frac12
$$

A bit of high level stuff, but I hope you guys follow. I believe that mathematics is an intuitive art that is innate to all, and I feel that most can follow if they think logically.

---

### Question

Derive the binomial theorem.

**Intuition:**

Now, from high school, we know that $(1 + x)^2 = 1 + 2x + x^2$. Similarly, we know $(1 + x)^3 = 1 + 3x + 3x^2 + x^3$. But how do we do this for a general $(1+x)^n$? One pattern pops out really quickly:

$$
(1+x)^n = 1 + \text{(something)} x + \text{(something else)} x^2 + \text{(something new)} x^3 + \cdots + \text{(another thing)} x^n
$$

But how do we determine the $\text{"something"}$s? Well, think about it: How would you get an $x$? You'd need to choose a single $x$ and let the rest be $1$s. Similarly, to get an $x^2$, you'd need to choose 2 $x$s and let the rest be $1$s. For now, though, we'll just focus on the first two parts:

$$
(1+x)^n = 1 + \text{(something)} x + \text{(blah)}
$$

So now, how do you get the $\text{(something)}$? You'd need to find out how we can choose 1 $x$. The number of $x$s we have is $n$, one from each $(1+x)$. How de we choose 1 $x$ out of $n$? We can choose the first, the second, the third, and so on until the nth. So we can make $n$ different choices. So we have:

$$
(1+x)^n = 1 + n x + \text{(blah)} \ge 1 + n x
$$

This works nicely for all $x \ge 0$ and also for negative $x$ as long as $x \in (-1,0)$.

Perfect. We're now ready. I hope I was clear.

**Proof:**

The quantity $(1 + x)^n$ is a polynomial of degree $n$. Hence, we can express it as the following:

$$
(1 + x)^n = c_0 + c_1 x + c_2 x^2 + \cdots + c_n x^n
$$

Now, look at $c_0$. How would we get the constant term? We must choose all none of the $x$s out of the $n$ choices we have. Similarly, for $c_1$, we'd need to choose 1 $x$ and let the rest be $1$s. In general, for $c_k$, we need to find the number of ways to choose $k$ objects out of $n$.

How do we do that? Well, if we have $k$ open spaces, we have $n$ choices for the first slot, $(n-1)$ choices for the second, $(n-2)$ for the third, and so on, with the $k$th slot having $(n-k+1)$ choices.

$$
P_k = n \cdot (n-1) \cdot (n-2) \cdots (n-k+1)
$$

However, this counts different shufflings as different things. That is to say, if we had to choose $k$ things from $n$ distinct things (say, the numbers from $1$ to $n$), then...

$$
\pi_1 = 1, 2, 3, \cdots, k\\
\pi_2 = 2, 1, 3, \cdots, k\\
$$

... are treated as unique, even though we chose the same things. So we need to divide by the number of ways we can shuffle $k$ things. How can we do that? The same argument applies: $k$ choices for the first place, $(k-1)$ choices for the second place, etc. So we need to divide by $k \cdot (k-1) \cdot (k-2) \cdots 3 \cdot 2 \cdot 1$, which we write as $k!$.

So we have:

$$
\begin{align*}
c_k &= \frac{n \cdot (n-1) \cdot (n-2) \cdots (n-k+1)}{k!}\\
&= \frac{n \cdot (n-1) \cdot (n-2) \cdots (n-k+1)}{k!} \cdot \frac{(n-k) \cdot (n-k-1) \cdots 2 \cdot 1}{(n-k) \cdot (n-k-1) \cdots 2 \cdot 1}\\
&= \frac{n \cdot (n-1) \cdot (n-2) \cdots (n-k+1) \cdot (n-k) \cdot (n-k-1) \cdots 2 \cdot 1}{k! ((n-k) \cdot (n-k-1) \cdots 2 \cdot 1)}\\
&= \frac{n!}{k!(n-k)!}
\end{align*}
$$

Therefore, for any integer $n \ge 0$

$$
\begin{align*}
(1 + x)^n = \sum_{k=0}^{n} \frac{n!}{k!(n-k)!} \cdot x^k = \sum_{k=0}^{n} \binom{n}{k} \cdot x^k
\tag*{$\mathfrak{Q.E.D.}$}
\end{align*}
$$

**Fun Fact:**

The value $\binom{n}{k}$ (pronounced "n-choose-k") is a deeply well studied concept, and an explicit formula for this was given by the Jain mathematician Mahavira.

Also, if we set $x=1$, we get a very beautiful result:

$$
\sum_{k=0}^{n} \binom{n}{k} = 2^n
$$

You might be wondering what $\binom{n}{0} = \frac{n!}{0! (n-0)!} = \frac1{0!}$ even means: how do you multiply $0$ things together? Well, that is defined to be $1$ as per the rules of multiplication, but more to the point: $\binom{n}{0}$ is "the number of ways to choose no objects out of $n$", which is... $1$. You don't choose anything.

---

### Question

Zeno is tired after a long day of work. He wants to take a gentle walk down the beautiful streets of Athens to a garden in the city square. The journey is 1 mile from his place. His friends tell him to go for a walk, but with a long face, he bemoans: "Alas! It is a fool's errand! I'll never reach there!"

He says: "I take a portion of time to walk half a mile, another portion for half of that, and yet another portion for half of that! I'm adding some positive quantity, and I'm doing it endlessly! Surely that would take me infinite time! I'll never reach there! The Gods are cruel!"

Can you comfort Zeno?

**Intuition:**

Practical experience tells us that Zeno's pain is unfounded. But how do we quantify it? Let's say he walks very slowly: 1 mile per hour.

First, he moves $\frac12$ mile, which he does in half an hour.  
Then, he move half of that, or $\frac14$ mile, which he does in half of half an hour, or 15 minutes.  
Then, $\frac18$ mile, in $\frac18$ of an hour, or 7 and a half minutes.

So the total time he takes is defined like so:

$$
T = \frac12 \text{ hour} + \frac14 \text{ hour} + \frac18 \text{ hour} + \cdots
$$

But how do we add an infinite number of things!? It makes no sense!

Worse, it seems like maths is contradicting physics! Common sense tells us that he'll reach the garden in 1 hour, but how does an infinite process end? Is maths a scam?!

Calm down, muchacho. Sarasvati doesn't abandon her children: believer's honour.

Let us break it down at a certain point:

$$
T_n = \frac12 \text{ hour} + \frac14 \text{ hour} + \frac18 \text{ hour} + \cdots + \frac1{2^n} \text{ hour}
$$

The idea is this: we will see how this finite thing behaves, and hopefully that will give us some understanding on the infinite case.

**Proof:**

We need to evaluate:

$$
T = \frac12 + \frac14 + \frac18 + \cdots 
$$

Let:

$$
\begin{align*}
T_n = \frac12 + \frac14 + \frac18 + \cdots + \frac1{2^n}
\end{align*}
$$

So clearly, $\lim_{n \to \infty} T_n = T$. Now,

$$
\begin{aligned}
T_n &= \frac12 + \frac14 + \frac18 + \cdots + \frac1{2^n}\\[4pt]
\frac12 T_n &= \frac14 + \frac18 + \cdots + \frac1{2^n} + \frac1{2^{n+1}}\\[4pt]
\end{aligned}
$$

Notice the repeating terms. Subtract them.

$$
\begin{aligned}
T_n &= \frac12 + \frac14 + \frac18 + \cdots + \frac1{2^n}\\[4pt]
\frac12 T_n &= \frac14 + \frac18 + \cdots + \frac1{2^n} + \frac1{2^{n+1}}\\[4pt]
\hline
T_n - \frac12 T_n &= \frac12 - \frac1{2^{n+1}}\\
\end{aligned}
$$

Therefore,

$$
\begin{aligned}
T_n - \frac12 T_n &= \frac12 - \frac1{2^{n+1}} \implies \frac12 T_n = \frac12 - \frac1{2^{n+1}}\\
\implies T_n &= 1 - \frac1{2^n}
\end{aligned}
$$

Now notice: Since $\frac12 < 1$,  raising it to higher powers will make it go closer and closer to $0$. So as $n \to \infty$, $T_n \to 1$. Zeno will reach the garden in 1 hour.

$$
\begin{align*}
T = \frac12 + \frac14 + \frac18 + \cdots = 1
\tag*{$\mathfrak{Q.E.D.}$}
\end{align*}
$$

**Fun Fact:**

This is known as Zeno's Paradox, a famous problem that first made us understand that an infinite number of things can add to a finite object. In general, we have:

$$
1 + x + x^2 + x^3 + \cdots = \frac{1}{1 - x}, \quad \text{for } |x| < 1
$$

This idea that an infinite number of things can add to a finite amount is the basis for calculus. The above formula was known to many groups across the world, including the Kerala School of Astronomy. Their headmaster, Madava of Sangamagrama, discovered this beautiful identity:

$$
\frac{\pi}{4} = 1 - \frac13 + \frac15 - \frac17 + \cdots
$$

---

[[another day of relaxing maths]]