---
title: peace.
updated: 2026-01-07 17:58:35Z
created: 2025-12-08 15:41:17Z
latitude: 17.68681590
longitude: 83.21848150
altitude: 0.0000
---

Hello! How are you guys doing? I hope all of you are doing well. Future therapist, I hope you're able to take care of your mental health. Future anthropology major, I hope your studies are going well. Future wifey... I hope life feels safe and happy.

You guys might've noticed that the recent entries have been different.

- I haven't really been sticking with my promise of keeping spirals out of my work.
- I have cut down the problem count from 3 per entry to one per entry. 

Both of these are due to a very simple thing. Soul-deep burnout. Emotional triage is becoming a daily reality. I am struggling, but I am still deeply, deeply grateful for this space, this place in my life where I am allowed to *be* without apology. Where I can show pain without couching it in platitudes, where I can show my love for math before adding a sarcastic *"Yeah, I know: I'm a psychopath"* behind it. It feels good.

Anyway, I'll share a problem today that is not only delightful in how weird and counter-intuitive it is, but also really important in the modern world, where mathematics is being weaponized by phonies who want to sell you something, or even worse in some cases. It is both beautiful *and* relevant!

---

### Question

Inside a bag, there is a ball which has an equal probability of being black or white. A white ball is dropped inside the bag, then a ball is randomly drawn out of the bag. The ball is found to be white. What is the probability that the ball inside is also white?

**Intuition:**

Hmmm... That's easy. 50-50. You put a white ball in, take it out, so the fundamental problem hasn't changed, has it?

Nope. I wouldn't include it here if the answer was that obvious, now would I? I know you guys may be tired reading this, but I want you guys feel *accomplished*, and trivial problems simply don't do this.

Let's map out the sample space, and then we'll try to arrive at this. Let us let $\mathfrak{U}$ be the undecided ball, the one which could either be white or black: $\mathfrak{U}$ for "undecided", of course. Also, let the known white ball be $\mathfrak{W}$ for "white."

Now our problem splits into two cases, both of which have probability $\mathfrak{P} = \frac12$ as they're equally likely:

- **Case 1:** $\mathfrak{U}$ is white, in which case both balls are white.
- **Case 2:** $\mathfrak{U}$ is black, in which case only one ball is white.

How does this change our calculation at all? Well, recall that we *have* to draw a white ball. This means each case splits to further cases, each of which we must analyze and either accept or reject based on our premises. Let's go through them.

- **Case 1:** $\mathfrak{U}$ is white, in which case both balls are white.
	- **Case 1A:** $\mathfrak{U}$ is drawn, which is white. Conditions are met, so this is an accepted microstate. In this case, the remaining ball is white.
	- **Case 1B:** $\mathfrak{W}$ is drawn, which is white. Conditions are met, so this is an accepted microstate. In this case, the remaining ball is white.
- **Case 2:** $\mathfrak{U}$ is black, in which case only one ball is white.
	- **Case 2A:** $\mathfrak{U}$ is drawn, which is **black**. Conditions are **not** met, so this is a rejected microstate.
	- **Case 2B:** $\mathfrak{W}$ is drawn, which is white. Conditions are met, so this is an accepted microstate. In this case, the remaining ball is black.
 
Noticed what happened there? The additional information of "the drawn ball is known to be white" has implicitly rejected some microstates: specifically **Case 2A**, where we drew a black ball. So our probability that the remaining ball is white is just the following...

$$
\begin{align*}
\mathfrak{P} &= \frac{\text{favorable outcomes}}{\text{total outcomes}}\\
&= \frac{\text{\# microstates where remaining ball is white}}{\text{\# total accepted microstates}} = \frac23
\end{align*}
$$

What we did here was an intuitive application of what is called Bayes’ Theorem, which looks like this...

$$
\mathfrak{P} (\text{Hypothesis is true given Evidence}) = \frac{
\mathfrak{P} (\text{Evidence if Hypothesis was true}) \cdot \mathfrak{P} (\text{Hypothesis})
} {\mathfrak{P} (\text{Evidence occurs at all})}
$$

The thing in our denominator can be written as a sum of weights: If we have many hypotheses $\{ \mathfrak{H_1}, \mathfrak{H_2}, \cdots, \mathfrak{H_n} \}$ such that only one of them can be true at a time, then we can write the denominator as follows:

$$
\mathfrak{P} (\text{Evidence occurs at all})
=
\sum_{k = 1}^n \mathfrak{P} (\text{Evidence occurs given } \mathfrak{H}_k \text{ is true}) \cdot \mathfrak{P} (\mathfrak{H}_k) 
$$

That sum may look scary, but it is essentially just our microstate analysis in disguise. Conventionally, our earlier formula for $\mathfrak{P} (\text{Hypothesis is true given Evidence})$ is written as so:

$$
\mathfrak{P} (\mathfrak{A_i \mid B})
=
\frac{
\mathfrak{P} (\mathfrak{B \mid A_i}) \cdot \mathfrak{P} (\mathfrak{A_i})
} {
\sum_{k = 1}^n \mathfrak{P} (\mathfrak{B} \mid \mathfrak{A}_k) \cdot \mathfrak{P} (\mathfrak{A}_k)
}
$$

In some cases, we may only have 2 hypotheses: $\mathfrak{A}$ and its opposite, written as $\neg \mathfrak{A}$. In that case, we have another, more simplified version:

$$
\mathfrak{P} (\mathfrak{A \mid B})
=
\frac{
\mathfrak{P} (\mathfrak{B \mid A}) \cdot \mathfrak{P} (\mathfrak{A})
} {
\mathfrak{P} (\mathfrak{B \mid A}) \cdot \mathfrak{P} (\mathfrak{A}) +
\mathfrak{P} (\mathfrak{B \mid \neg A}) \cdot \mathfrak{P} (\neg \mathfrak{A})
}
$$

Let us now see how a seasoned statistician would work with this problem.

**Proof:**

First, some terminology.

- Let $\mathfrak{X}$ = "The original ball in the bag is white"
- Let $\mathfrak{Y}$ = "The ball drawn after adding white ball is white"

Why lock in on the original ball? Because it is equivalent to talking about the remaining ball **given the boundaries of our experiement (i.e. adding a white ball and drawing a random one).** Since we know that the ball drawn afterward is *known* to be white, the ball inside can be black if and only if our original ball was black.

(This is the weird thing about conditional probability, and why so many people trip over it, including myself. I had to get my doubts clarified by an LLM.)

Now, by Bayes' Theorem,

$$
\mathfrak{P} (\mathfrak{X \mid Y})
=
\frac{
\mathfrak{P} (\mathfrak{Y \mid X}) \cdot \mathfrak{P} (\mathfrak{X})
} {
\mathfrak{P} (\mathfrak{Y \mid X}) \cdot \mathfrak{P} (\mathfrak{X}) +
\mathfrak{P} (\mathfrak{Y \mid \neg X}) \cdot \mathfrak{P} (\neg \mathfrak{X})
}
$$

Let us calculate each term.

- Due to our conditions, $\mathfrak{P(X)} = \mathfrak{P(\neg X)} = \frac12$.
- $\mathfrak{P} (\mathfrak{Y \mid X})$ is the probability of drawing a white ball if the original was also white, which is $1$: there are only white balls to choose from.
- $\mathfrak{P} (\mathfrak{Y \mid \neg X})$ is the probability of drawing a white ball if the original was black, which is $\frac12$: there are $2$ outcomes out of which one is favorable.

Putting them in, we get:

$$
\begin{align*}
\mathfrak{P} (\mathfrak{X \mid Y})
&=
\frac{
\mathfrak{P} (\mathfrak{Y \mid X}) \cdot \mathfrak{P} (\mathfrak{X})
} {
\mathfrak{P} (\mathfrak{Y \mid X}) \cdot \mathfrak{P} (\mathfrak{X}) +
\mathfrak{P} (\mathfrak{Y \mid \neg X}) \cdot \mathfrak{P} (\neg \mathfrak{X})
}\\
&= \frac{1 \cdot \frac12}{1 \cdot \frac12 + \frac12 \cdot \frac12} = \frac{\frac12}{\frac34} = \frac23
\implies \mathfrak{P(X \mid Y)} = \frac23
\end{align*}
$$

Which is the required result.

$$
\mathfrak{P} = \frac23
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

This is often called "Lewis Carroll's Pillow Problem" in mathematical communities because, fun fact, Charles Lutwidge Dodgson (better known as Lewis Carroll) was a mathematician: he got an M.A. in mathematics from Christ Church, Oxford. He was a man who suffered from many mental health issues and often had, by his own admission, deeply intrusive thoughts. In his book *Pillow Problems and A Tangled Tale*, he writes the following:

> Perhaps I may venture for a moment to use a more serious tone, and to point out that there are mental troubles, much worse than mere worry, for which an absorbing object of thought may serve as a remedy.
> 
> - There are sceptical thoughts, which seem for the moment to uproot the firmest faith;
> - there are blasphemous thoughts, which dart unbidden into the most reverent souls;
> - there are unholy thoughts, which torture with their hateful presence the fancy that would fain be pure.
>
> Against all these some real mental work is a most helpful ally. That “unclean spirit” of the parable, who brought back with him seven others more wicked than himself, only did so because he found the chamber “swept and garnished,” and its owner sitting with folded hands. Had he found it all alive with the “busy hum” of active work, there would have been scant welcome for him and his seven!

He later denied having issues with insomnia, writing thusly in the second edition of the same book:

> In the title of the book [Pillow-Problems, 2nd edition], the words “sleepless nights” have been replaced by “wakefull hours”.
> This last change has been made in order to allay the anxiety of friends, who have written to me to express their sympathy in my broken-down state of health, believing that I am a sufferer of chronic “insomnia”, and that it is a remedy for that exhausting malady that I have recommended mathematical calculation.
> The title was not, I fear, wisely chosen; and it certainly was liable to suggest a meaning I did not intend to convey, viz. that my “nights” are often wholly “sleepless”. This is by no means the case: I have never suffered from “insomnia”: and the over-wakeful hours, that I have had to spend at night, have often been simply the result of the over-sleepy hours I have spent during the preceding evening! Nor is it as a remedy for wakefulness that I have suggested mathematical calculation: but as a remedy for the harassing thoughts that are apt to invade a wholly-unoccupied mind.

I don't know... I know defensiveness when I see it. It feels like Lewis Carroll is performing normalcy for his peers: we all know how bad mental health treatments were back then, no?

Here's a side of me you don't get: the researcher. It was an absolute pain to get this dumb thing, because even though I'm 101% sure it is in the public domain, I can't bloody find the bloody book. I'm going purely off of a secondary source I found, that being [this.](https://snrk.de/mental-troubles/)

---

The author of this blogpost chimes in with his own theory about Lewis Carroll's mental health:

> I think that one of these serious conflicts was Charles Darwin’s challenge to fundamental religious beliefs. The discoveries of Darwin and other researchers surely had (and still have) the potential to uproot the firmest faith in various religions.

I... I dunno. I felt slightly attacked by that. I never found any conflict in my faith and in science, but I get reminded of all the times that science was weaponized against me back when I was a kid. Science has been weaponized against me so many different times that at this point I've essentially associated that subject with pain. 

This one time I was watching a video where the presenter was a science channel talking about a cult leader promoting some really weird and unscientific beliefs couching them in philosophical language which, as it turns out, that is the language of Vedanta. I gave a theological argument against the cult leader in the comments, and that was the biggest mistake.

I got attacked by a guy saying that people like me are the reason why cult leaders like him exist. It shook me so much as a child that I just straight up deleted my email. Not just my YouTube account, but my entire email altogether. I created a new one after that.

Then, in some scientific forums, I found a thread about the existence of God, and I tried to talk about my personal experience, and what did I get in return? "You're just deluding yourself, kid. Get a shrink to tell you that Santa Claus isn't real." "Yeah, I said {Offensive, sexualized insult directed at Sarasvati}. What are you gonna do? Cry to your imaginary friend about it? What a loser." "Imagine studying in STEM and still believing in God. How dumb do you gotta be?" "Imagine the cognitive dissonance he must have to hold such foolish ideas of imaginary friends alongside physics and math. Couldn't be me!"

I remember one which called itself "Science Journey", but in reality, it was filled with pseudo-historical Hinduphobic BS— they made claims that the Upanishads supported sexual exploitation of women and that Buddhism predates Hinduism by many millenia and that Hinduism only arose in the 1800s, all mixed in with a healthy dose of hate speech.

I, being vulnerable from losing my father just a few years back, internalized so much of that painful messages, and I had no healthy outlet to vent my hurt; everyone would simply question why I'm giving those people so much mental space.

It's about to be midnight in a bit. I'm right at the time he might've been in bed, staring at the ceiling while trying to calm himself down, thinking about balls in a bag, trying to let his mind settle enough to finally rest.

I came in thinking "Ah, what a quaint way to introduce Bayesian Reasoning! I can talk about the O.J Simpson case, the prosecutor's fallacy, and perhaps I could make a joke about Lewis Carroll trying to ward off unholy thoughts by pondering balls in a sack!"

But no. I feel sad instead.

I won't laugh on a struggling man's method to soothe his mind. I'm better than that.

[[nobody can hurt you here]]