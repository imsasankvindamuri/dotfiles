---
title: so tired...
updated: 2026-01-07 17:59:06Z
created: 2025-12-16 12:27:00Z
latitude: 17.38504400
longitude: 78.48667100
altitude: 0.0000
---

Hello... I hope you're well, future wifey, future therapist, and future anthropology student analyzing my work. I often only address my future wifey, but please: don't feel left out.

My final semester is underway, and I am... not doing great, I'll be fully honest. I was in constant anxiety today, and I still kinda am as of typing this. I would rather be with the beauty of the math than to linger on my pain.

Today, we'll look at a beautiful part of math, the $\mathrm{AM\text{-}GM}$ inequality, which we will prove two different ways: one through arithmetic, and another through geometry. This is another "beautiful derivation" entry rather than a "can you find it?" entry, so sit back and watch the beauty before you.

---

### Question

Prove that for $a,b \in \mathbb{R}^+$,

$$
\frac{a+b}{2} \ge \sqrt{ab}
$$

**Intuition:**

The classic, boring, "textbook" derivation looks like this. If you want to skip this, you have my blessing. The other proof is nicer anyway IMHO.

*Dramatically clears throat.*

Without loss of generality, let $a \ge b$. Therefore, $\sqrt{a} \ge \sqrt{b}$ as $\sqrt{x}$ is an increasing function. So,

$$
\begin{align*}
\sqrt{a} - \sqrt{b} &\ge 0\\
\implies \left( \sqrt{a} - \sqrt{b} \right)^2 &\ge 0\\
\implies a + b - 2\sqrt{ab} \ge 0 &\implies a + b \ge 2\sqrt{ab}\\
\implies \frac{a+b}{2} &\ge \sqrt{ab}
\tag*{$\mathfrak{Q.E.D.}$}
\end{align*}
$$

Hmmm... This proof feels like the mathematical equivalent of ending a story with "... and they woke up and found out it was all just a dream. The End." It's unsatisfying, it feels obtuse, and the square root comparison feels like it fell from a coconut tree. It gives you the answer with minimal effort, sure. But you gain 0 insight from it. It feels like it was beat onto your head by an angry teacher, which is the worst type of feeling in math, and one that is, very unfortunately, extremely common in the modern day.

How do we fix this sorry state of affairs? With a famous geometric proof, of course!

**Proof:**

<p style="text-align:center;">
	<img src="../_resources/am-gm-inequality.svg" /> 
	<strong>The AM-GM Inequality</strong>
</p>

Above, you see a very interesting diagram. The important parts for the inequality are in solid black, while constructions are dotted and in gold:

- We have a line segment $\mathrm{PQ = PX + QX}$, which makes the diameter of the semicircle $\mathrm{PYQ}$. As such, the radius of the circle is $\mathrm{OP = OQ = OY = \frac{PX + QX}{2}}$.
- We have the line segment $\mathrm{XY}$, which we'll measure in a moment and who is perpendicular to $\mathrm{PQ}$
- We have our constructions $\mathrm{PY}$ and $\mathrm{YQ}$.

Great. Let's make a mental note that $\mathrm{OY = \frac{PX + QX}{2}}$, OK?

The important note is that $\angle \mathrm{PYQ} = \angle \mathrm{PXY} = 90 \degree$ (or $\frac{\pi}{2} \text{ rad}$.) I'll take this as a given for now via something called Thales' Theorem, but if you're feeling adventurous, you can try proving it yourself. No pressure, though.

Now, since $\angle \mathrm{PYQ}= 90 \degree$ and $\angle \mathrm{PYQ}= \angle \mathrm{PYX} + \angle \mathrm{XYQ}$, we get that $\angle \mathrm{XYQ} = 90 \degree - \angle \mathrm{PYX} = \angle \mathrm{YPX}$.

Since both $\Delta \mathrm{PYX}$ and $\Delta \mathrm{QYX}$ both have the same angles $\angle \mathrm{YPX} = \angle \mathrm{XYQ}$ and since $\angle \mathrm{PXY} = \angle \mathrm{QXY}$, the remaining angle gets constricted and we get that $\Delta \mathrm{PYX} \sim \Delta \mathrm{QYX}$, meaning that their aspect ratios are the same. Perfect.

So, we have:

$$
\begin{align*}
\frac{\mathrm{XY}}{\mathrm{PX}} &= \frac{\mathrm{QX}}{\mathrm{XY}}
\tag{$\text{From } \Delta \mathrm{PYX} \text{ and } \Delta \mathrm{QYX}$}\\
\implies \mathrm{XY}^2 &= \mathrm{PX \cdot QX}\\
\implies \mathrm{XY} &= \sqrt{\mathrm{PX \cdot QX}}
\end{align*}
$$

Let's make this our second mental note.

However, by the "Pythagorean" theorem,

$$
\mathrm{OY^2 = OX^2 + XY^2} \implies \mathrm{OY^2 \ge XY^2}\\
\implies \mathrm{OY \ge XY}
$$

By combining both mental notes, we get

$$
\mathrm{\frac{PX + QX}{2} \ge \sqrt{PX \cdot QX}}
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

Isn't that beautiful? You can literally *see* why it's true. And better yet, you can go hog-wild with inequalities, though I'll leave that to you if you're interested.

Of course, like with many things in math, there is a generalization. For a set of non-negative reals $\{ x_1, x_2, x_3, \cdots, x_n \}$, we have this:

$$
\frac{x_1 + x_2 + x_3 + \cdots + x_n}n \ge \sqrt[n]{x_1 \cdot x_2 \cdot x_3 \cdots x_n}
$$

This is... surprisingly hard to prove. Needs a lot of heavy machinery. You need all sorts of mathematical superweapons.

Be that as it may, I genuinely hope this beautiful geometric proof lit up your day.

[[little steps + persistence = beauty]]