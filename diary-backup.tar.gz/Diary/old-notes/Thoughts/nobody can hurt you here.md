---
title: nobody can hurt you here...
updated: 2026-01-07 17:58:51Z
created: 2025-12-10 14:32:53Z
latitude: 17.68681590
longitude: 83.21848150
altitude: 0.0000
---

Welcome back. I hope all of you are having a nice day. No fear if you're feeling trash, either... everyone is welcome here. We all go through rough patches, and some may even go through mental health issues, but all are welcome here. I myself suspect that I am depressed, and recently, it's been feeling really heavy and painful. My faith in Sarasvati Amma is the main thing holding me in place, and I hope that I'll be able to get help as soon as possible.

I hope you're doing well, wifey. Let's get directly into today's stuff. I have a few things planned for today.

---

### Question

It is your birthday, and we've got a chocolate cake that we both like. However, we both love cake a bit too much, and we want take as much cake as possible for ourselves. Is it still possible for the two of us to split the cake so that nobody is envious of the other? Assume that I am the person cutting the cake.

**Intuition:**

Hmm... this is weird. Won't I always have an advantage? I could make an unfair cut to always take the better portion, no? What's stopping me?

Yes. Yes, that's true. If I am in charge of both cutting and splitting the cake, then yes, I win every time. I'll just take a large slide and leave you with a small crumb. No offense, I just love chocolate cake!

So... is all hope lost? Are you destined to lose all your cake to me, your greedy, cake-loving mathematician?

I wouldn't give up so quickly. Because even if you can't cut, you still have power: the power to choose.

That's all I'm giving you for now. You can try with these hints, or keep reading: I won't judge either way. I was also dumbfounded by this question until I reasoned through with the above hint.

**Proof:**

Yes. There is a way.

- I cut the cake into as many slices as I please in whatever way I please.
- Once all the cuts are done, you must split them up so that each person gets at least one slice.

Why does this work? Well, for a perfectly fair cut, both of us need to get exactly $\frac12$ of the cake. Now let us see how our setup disincentivizes funny business.

- Let's say I cut the cake into $\mathrm{n}$ pieces, hoping to take the lion's share and leave you with a small crumb. Then, since you choose, you'll just choose the top $\mathrm{n-1}$ largest pieces and leave me with the smallest piece. So I'm disincentivized from making more than one cut.

- Let's say I do decide to cut it into half, but unfair halves: something like $90\%/10\%$ or $70\%/30\%$, hoping to take the larger share. The same thing happens: you take the larger share and leave me with the smaller one.

So, my own love for chocolate cake **forces** me to make a fair cut and give you your fair share. If anything, I'm at a slight disadvantage here: if I make a mistake, you reap the benefits. So I am deeply incentivized to make the fairest possible cut so that I don't lose out.

We have found a cooperative strategy to split cake.

$$
\text{Yes, a strategy exists.}
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

Wait a goddamn minute... is this math?! Where are the numbers?

Yes, it is. It is a field called "Game Theory": the study of interactions between rational so-called "players."

I don't like the name, to be honest: I think "Interaction Theory" would be better. For one thing, games like basketball and football are excluded as they're more about physical skill and instinct rather than "rationality." Similarly, things like a board meeting or war or even just bargaining with the grocer, which we wouldn't consider games, are "games" in the eyes of game theory as they involve several rational actors trying to maximize their gain. So I think the name "Game Theory" is pretty misleading.

Bad name or not, game theory is very important in the modern day. It often informs policy decisions, investments, etc. In many ways, it kinda runs the world, as all social interactions are "games" and thus have a theoretical "optimal response." It's no surprise that it appears everywhere, from biology to academic dishonesty to income inequality. Seriously, I actually tried to perform a game-theoretic analysis of the effects of societal pressure on academic institutions and students, and how that may contribute to the rampant cheating we can sometimes see in Indian academia.

Was my analysis based partly on my own bitterness at being forced to a field I don't like and then being expected to ace the subjects I hated? Yes. Do I still think I made a proper, objective analysis without letting my anger cloud judgement? Yes. I'm sure that if I weren't so depressed, I would actually be able to get numbers to back stuff up.

What we just saw is often called the Fair Division Problem: "How do $\mathrm{n}$ people fairly split a certain resource?" In our case, we were engaged in a 2-player Fair Division Problem with chocolate cake as our resource. The proper way to divide fairly becomes harder with more than $2$ people, but I still encourage you to try doing the same to $3$ or $4$ people. It could be a fun brain teaser to think about while trying to sleep. No pressure, though.

This actually reminds me of a very funny parable that I found in a small Telugu storybook I had as a child. The name of the parable was "Mutyapu Chippa" (lit. "shell of pearls"; refers to clams.)

> ## Mutyapu Chippa: A Telugu Parable
>
> Two travellers were walking along the beach, and they spotted a clam shell, presumably filled with pearls. So, they began fighting over it, blinded by greed. "I picked it up first!" says one person. "Therefore, I deserve the clam!" "No!" says the other. "I saw it first. Therefore, I deserve the clam!"
>
> Their greed makes them fight with each other with no resolution in sight. While this is happening, a wayfarer walks in and asks them what is wrong, and the travellers explain their plight. "Good sir, I deserve this clam because I had picked it up first!" "No, sir! I deserve it because I saw it first!"
>
> The wayfarer snickers to himself and then says, "Well, why don't you let me split the treasure fairly?" The foolish travellers agree. The wayfarer takes the clam, opens it, pockets all of the pearls, and gives each of them one half of the shell, and walks away.

Alas! If only these travellers knew about game theory, this grave tragedy may have been prevented!

---

I'm really struggling to find hope. I'll be honest. I'm holding on, but... I'm tired. I want a hug. I want kiss on the cheek. I want to fall asleep in someone's lap. I want to work on the things I want without hiding or feeling soul-deep guilt that I am failing everyone I love and without feeling a soul-destroying pain pondering what could've been.

When I was younger, I used to hear tales of humans or Gods or Demons performing many years of *tapas* or penance to gain the favor of the Great Gods like Brahma, Vishnu, Sarasvati, Shiva, and such, only to ask for the most dumb, earthly desire possible. And... I always looked at them with utter disbelief and incredulity. "Why are you craving infinite power instead of moksha? You could ask for literally anything, yet you tie yourself to the world and sign your death warrant? How foolish! I would've chosen differently."

My incredulity stands, but for a different reason. "What point is there for infinite power? Does it hold a candle to being able to pray in peace? To arriving home to a wife who loves you dearly? To doing what you love? To making the lives of the few people you know just a tiniest bit brighter?"

Heh. Why would they know? They didn't have their inner temple desecrated by unbelieving, cruel people. They didn't have their hopes of getting a loving wife shattered by a cruel pipeline invented by NTR pornographers looking to get a quick buck. They weren't depressed. They didn't have their heart ripped apart into trauma shock by their father's passing. They don't question whether they're the worthless ones for not being able to keep up, whether they're the good-for-nothings because they struggle with the simplest task. These Gods, Demons, and humans... they don't know how good they have it.

It's been over a month since my 21st birthday, Sarasvati Amma. For my present, I'd like to have a wife who loves me, a warm home, a mathematics textbook, and the freedom to investigate beautiful problems. Yes, Amma... I know that this is impossible, but one can delude oneself, no? Please say yes. Please say I can still hope. That I'm not disqualified from wanting something for myself, for wanting a warm nest, from wanting to be happy, from praying without pain.

I feel drained. Broken.

I... I don't even know anymore. I'm just a robot at this point. The math is the only thing that makes me feel human. My soul dies every time I open my code editor, and these entries and the math in them are the only things that remind me that I am also a human being that has wants and needs.

My sister heard about my anxiety issues (I get literal panic attacks when I hear notifications from my phone) and suggested that I speak to a therapist, and she's even considering finding one for me. I hope things will be OK...

[[so tired]]