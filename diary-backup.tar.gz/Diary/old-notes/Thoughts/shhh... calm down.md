---
title: 'shhh... calm down. '
updated: 2025-12-16 07:32:32Z
created: 2025-12-05 14:10:58Z
latitude: 17.68681590
longitude: 83.21848150
altitude: 0.0000
---

Hello... I hope you're all having a good day. Have you guys eaten? Did you sleep well last night? Please take care of yourselves, anthropology major, future therapist, and wifey. Especially you, anthropology major. You're a student. You've already got a lot on your plate. Please, go to sleep if it's late. I'll do the same soon enough. 

Today was... rough. I felt like trash. Had an existential breakdown. I'm trying to ground myself with devotional songs: both traditional ones like *Ninnu Vidisiyundalenayya* and modern ones like *Sada Siva Sanyasi* from *Khaleja.* Have you guys seen that movie? You really should. Meme goldmine, laugh riot, but such a heartwarming and beautiful movie. It's a comfort movie for me.

Anyway... I'm feeling real sad. So... time for some relaxing math.

---

### Question

Two upright pillars of differing heights stand parallel to each other. Two ropes are stretched between them. One goes from the zenith of the first pillar to the nadir of the second. Another goes from the zenith of the second pillar to the nadir of the first. Where these two ropes meet, a third rope is tied and stretched taut to the ground such that it is parallel to the two pillars. What is the length of this third, taut piece of rope?

<p style="text-align:center;">
	<img src="../_resources/desmos-graph.svg" /> 
	<strong>Mahavira's Pillar Problem</strong>
</p>

**Intuition:**

It's surprising, no? I promised relaxing math problems, but this is the first geometry problem. Well... I was afraid of using up too much space with pictures, but now that I've learned to embed SVGs, I'll try to include more of them.

Now, you can use coodinate geometry here, sure. But...

1. It's inelegant.
2. It's like using a bazooka to kill a horsefly.

Instead, we'll use proportionality arguments, just like how it would've been done in ancient times.

**Proof:**

It is given that $\mathrm{AB} \parallel \mathrm{XY} \parallel \mathrm{CD}$ and that $\mathrm{AB} \perp \mathrm{AC}$. Therefore, $\angle{\mathrm{BAX}} = \angle{\mathrm{YXC}} = \angle{\mathrm{XCD}} = \frac{\pi}{2}$, otherwise known as $90 \degree$.

Now note that the sum of all the angles in any triangle is $180 \degree$ by the Fifth Postulate of Euclidean Geometry (Yes, it's a postulate, not a theorem. It is a fact we take for granted, not something derived, in case you didn't know.) Therefore, if we look specifically at $\Delta \mathrm{XYC}$ and at $\Delta \mathrm{ABC}$, we get the below notes:

$$
\begin{align*}
\angle{\mathrm{ABC}} + 90 \degree + \angle{\mathrm{XCY}} &= 180 \degree
\tag{$\text{From } \Delta \mathrm{ABC}$}\\
\angle{\mathrm{XYC}} + 90 \degree + \angle{\mathrm{XCY}} &= 180 \degree
\tag{$\text{From } \Delta \mathrm{XYC}$}\\
\implies \angle{\mathrm{XYC}} = \angle{\mathrm{ABC}}
\end{align*}
$$

With a similar argument, we can say that $\angle{\mathrm{CDY}} = \angle{\mathrm{XYA}}$.

Therefore, $\Delta \mathrm{ABC} \sim \Delta \mathrm{XYC}$ and $\Delta \mathrm{ADC} \sim \Delta \mathrm{XYA}$. What does that mean? It means that $\Delta \mathrm{XYC}$ and $\Delta \mathrm{ABC}$ are scaled copies of each other, and similarly with $\Delta \mathrm{ADC}$ and $\Delta \mathrm{XYA}$. What that means is that the ratio of their corresponding sides are the same.

$$
\begin{align*}
\frac{\mathrm{XY}}{\mathrm{AB}} = \frac{\mathrm{XC}}{\mathrm{AC}} = \frac{\mathrm{YC}}{\mathrm{CB}}
\tag{$\text{From } \Delta \mathrm{ABC} \text{ and } \Delta \mathrm{XYC}$}\\
\frac{\mathrm{XY}}{\mathrm{DC}} = \frac{\mathrm{XA}}{\mathrm{AC}} = \frac{\mathrm{YA}}{\mathrm{AD}}
\tag{$\text{From } \Delta \mathrm{ADC} \text{ and } \Delta \mathrm{XYA}$}\\
\end{align*}
$$

We'll only need the first two parts of each equality.

$$
\begin{align*}
\frac{\mathrm{XY}}{\mathrm{AB}} = \frac{\mathrm{XC}}{\mathrm{AC}}
\tag{1}\\
\frac{\mathrm{XY}}{\mathrm{DC}} = \frac{\mathrm{XA}}{\mathrm{AC}}
\tag{2}\\
\end{align*}
$$

Adding both of these, we get the following:

$$
\begin{align*}
\frac{\mathrm{XY}}{\mathrm{AB}} + \frac{\mathrm{XY}}{\mathrm{DC}}
&= \frac{\mathrm{XC}}{\mathrm{AC}} + \frac{\mathrm{XA}}{\mathrm{AC}}\\
&= \frac{\mathrm{AC}}{\mathrm{AC}} = 1
\tag{$\because \mathrm{XC + XA = AC}$}\\
\end{align*}
$$

$$
\begin{align*}
\implies \frac{\mathrm{XY}}{\mathrm{AB}} &+ \frac{\mathrm{XY}}{\mathrm{DC}}
= 1\\
\implies \frac1{\mathrm{XY}} &= \frac1{\mathrm{AB}} + \frac1{\mathrm{DC}}
\end{align*}
$$

Therefore, we get our final answer:

$$
\mathrm{XY} = \frac1{\frac1{\mathrm{AB}} + \frac1{\mathrm{DC}}}
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

This problem can be found in the Ganitasarasangraha, a mathematical text written by the Jain mathematician Mahavira, and it dates back to at least **850 AD**.

Nothing much to say here, to be honest. Just a nice, simple geometry problem.

---

I felt really raw and hurt today, so I began doing this while listening to melancholic Shaivite songs (Telugu literature is filled with such songs) while typing this. Earlier, I was doing this to ground myself, but tragedy struck! My brother took my phone to watch brainrot loudly on Insta, and I was (and still am) deeply miffed about that. Not only because it was annoying, not only because he could've watched Insta on his phone rather than on mine but chose not to, but because beautiful, painful songs talking about devotion in the face of hardship and existential despair got replaced with jokes about sleeping with other people's parents and weird conspiracy theory bullshit.

Seriously, imagine the whiplash for a sec:

> Before: (tranl. from Telugu)
> "Shiva Mahadeva Shankara, Thou art our only kith and kin...
> Be Thou our final refuge, O Samba Shiva, God of Gods..."
>
> After: uwu *nokia sound effect* BABABOOEY Yeh-heh, boi (insert more sound effects here)

At least I can gain some amusement: my brother is watching Insta on my phone because it isn't in his iPhone. Why? He deleted it so that he won't spend so much time on Insta.

I don't know whether I should feel confused, impressed, or annoyed. And at this point, I'm too emotionally exhausted to think about it.

[[beauty shall be your solace]]