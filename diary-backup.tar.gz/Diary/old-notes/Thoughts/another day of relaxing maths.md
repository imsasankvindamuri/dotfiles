---
title: another day of relaxing maths
updated: 2025-12-10 14:38:58Z
created: 2025-11-24 03:58:22Z
latitude: 17.38504400
longitude: 78.48667100
altitude: 0.0000
---

Hello, it's me again. I hope you are doing well, future wifey, anthropology major, and therapist.

I have my repeat exams in a few days: specifically for "Optimization Techniques and LPPs" as well as "Object Oriented Software Engineering." I'll need to study for that. If you're wondering how I failed LPPs, well... I was going through stuff. Couldn't focus. Fortunately, my professor was understanding and helped me. Hell, he was surprised I was even there, as he saw me as a capable student. Also, this repeat course meant I was in self-study rather than in a fast-paced lecture, allowing me to come up with interesting insights, like how the Simplex method (which we use to perform profit-loss analyses) is simply a way to systematically look at every corner of a shape. Very enlightening.

As for OOSE... I hate OOSE. I don't wanna talk about the Actor model or whatever. This is a safe place. Only things that feel good will be here. I want this place to be a place of relaxation.

---

### Question

Evaluate the sum

$$
\mathfrak{S} = \frac11 + \frac1{1+2} + \frac1{1+2+3} + \frac1{1+2+3+4} + \cdots
$$

**Intuition:**

We'll follow the same idea as we did in Zeno's Paradox: we will look at a truncated sum $\mathfrak{S}_n$ and see how it behaves as $n \to \infty$. But for that, we need a general way to look at the sum of the first $n$ natural numbers. Hmm...

Well, we'll follow a very precocious elementary-schooler... a certain Carl Friedrich Gauss.

Little Carl had a taskmaster for his teacher, who was a very stict, no-nonsense maths teacher. One day, the taskmaster had some work to do, so he gave the children a very difficult problem to solve to keep them silent.

$$
\mathcal{S_{100}} = 1 + 2 + 3 + \cdots + 98 + 99 + 100\\
\mathcal{S_{100}} = \text{ ?}
$$

The little children scurried to their slates, doing calculations. One murmured, "One plus two is three, plus three is six, plus..." while another said, "No, Johan! Do the hard bits first! One hundred plus ninety-nine is a hundred ninety-nine, plus ninety-eight is... uhh..." And then, little Carl yelled: "The answer is five thousand and fifty!"

A stern voice boomed: "Guessing? Are you in such despair as to place faith on dumb luck, Master Gauss?"

"No sir."

"Then please, tell us: how did you find the answer?"

Carl walked up to the chalkboard and began writing:

$$
\begin{aligned}
\mathcal{S_{100}} = 1 + 2 + 3 + \cdots + 98 + 99 + 100\\[4pt]
\mathcal{S_{100}} = 100 + 99 + 98 + \cdots + 3 + 2 + 1\\[4pt]
\hline
2 \mathcal{S_{100}} = 101 + 101 + 101 + \cdots + 101 + 101 + 101
\end{aligned}
$$

"$1 + 100 = 101$, $2 + 99 = 101$, and so on..." Carl explained, "How many $101$s do we have? Exactly $100$."

$$
2\mathcal{S_{100}} = 101 \cdot 100 \implies \mathcal{S_{100}} = \frac{101 \cdot 100}{2} = 5050
$$

Applause for one very smart elementary schooler!

Applying this to $n$, we get this: "$n + 1 = (n+1)$, $(n-1) + 2 = (n+1)$, and so on... How many $(n+1)$s are there? Exactly $n$. So, $2\mathcal{S_n} = (n+1) \cdot n$." Therefore...

$$
\mathcal{S_n} = \frac{n \cdot (n+1)}{2}
$$

Applause to you!

**Proof:**

Let

$$
\begin{aligned}
\mathfrak{S_n} &= \frac11 + \frac1{1+2} + \frac1{1+2+3} + \cdots + \frac1{1+2+3+\cdots+n} = \sum_{k=1}^{n} \frac1{\mathcal{S_k}}\\
&= \sum_{k=1}^{n} \frac1{\frac{k \cdot (k+1)}{2}} = \sum_{k=1}^{n} \frac2{k \cdot (k+1)}
= 2 \sum_{k=1}^{n} \frac1{k \cdot (k+1)}
\end{aligned}
$$

(Please don't get scared of the Greek letters. $\Sigma$ is not here to hurt you. He is here to make our job easier.

The $\Sigma$ just means "add up". The $k=1$ in the bottom means "start by plugging in $1$". The $n$ on top means "keep goung until the number $n$". So in all, the symbol means "Plug $1$ into $\frac1{k \cdot (k+1)}$, then $2$, and so on until $n$, and then add them all up." That's all.)

Now note:

$$
\begin{align*}
\frac1{k \cdot (k+1)} &= \frac{k + 1 - k}{k \cdot (k+1)}
\tag{$\text{A cheeky trick!}$}\\
&= \frac{k + 1 - k}{k \cdot (k+1)} = \frac{(k + 1) - k}{k \cdot (k+1)} = \frac{(k + 1)}{k \cdot (k+1)} - \frac{k}{k \cdot (k+1)}\\
\frac1{k \cdot (k+1)}&= \frac1k - \frac1{k+1}
\end{align*}
$$

So,

$$
\begin{aligned}
\mathfrak{S_n} &= 2 \sum_{k=1}^{n} \frac1{k \cdot (k+1)} = 2 \left[ \sum_{k=1}^{n} \left( \frac1k - \frac1{k+1} \right) \right]\\
&= 2 \left[ \left( \frac11 - \frac12 \right) + \left( \frac12 - \frac13 \right) + \left( \frac13 - \frac14 \right) + \cdots + \left( \frac1{n-1} - \frac1n \right) + \left( \frac1n - \frac1{n+1} \right) \right]\\
&= 2 \left[ \frac11 - \frac12 + \frac12 - \frac13 + \frac13 - \frac14 + \cdots + \frac1{n-1} - \frac1n + \frac1n - \frac1{n+1} \right]\\
\end{aligned}
$$

We get some clean cancellation here: only the $\frac11$ and $\frac1{n+1}$ are spared.

$$
\begin{align*}
\mathfrak{S_n} = 2 \left[ 1 - \frac1{n+1} \right] = 2 - \frac2{n+1}
\end{align*}
$$

As $n \to \infty$, $\mathfrak{S_n} \to \mathfrak{S}$, and the term $\frac2{n+1} \to 0$, so we get another beautiful answer

$$
\begin{align*}
\mathfrak{S} = \frac11 + \frac1{1+2} + \frac1{1+2+3} + \frac1{1+2+3+4} + \cdots = 2
\tag*{$\mathfrak{Q.E.D.}$}
\end{align*}
$$

**Fun Fact:**

This is known as a "telescoping series", probably because it collapese like those old-timey telescopes that pirates seem to use. The sum in Zeno's Paradox was also a sort of a telescope, but this is the textbook example. Very clean.

---

I guess some openness is needed here. I said I was going through a lot, and that I don't want to talk about it. But you guys reserve the right to know all this: future therapist so that you can help me, future anthropology major so that you can understand the pain of a young adult in the 2020s, and future wifey because... if I don't tell it to you, then to whom will I tell it to?

But please know: I won't linger on them. They cause terrible spirals, especially if I linger too long on them. So please don't expect any further explanations.

I was exposed really early to porn. Mostly stuff involving betrayal, infidelity, cuckolding, "mindbreaking", and coercive domination. Some of the scenes in the things I saw... they talked about how humans are still governed by animal instinct. That deep down, all a person wants is the fittest, most conventionally attractive and "manly" man out there with penises the size of those 15 cm scales you get in a geometry box. That a soft, chubby, reserved, and emotionally struggling guy like me will be abandoned for a "masculine", chiselled, successful, and stoic Adonis. I got exposed and addicted when I was 12 and ended when I was 18, and have been clean since.

Aside from that, I've faced religious mockery and religious bullying from the internet, with a lot of internet anons drawing incredibly degrading pictures of my Goddesses. To this day, I cannot pray in my puja room or meditate without intrusive thoughts. Mathematics is how I pray.

The internet... broke the bridge between myself and my Gods. Every time I try to sit down and work with pure faith, I'm just attacked by constant nagging arguments within my head about trying to prove God. I remember so many long nights and days as a child, crying as I wrote proofs of God's existence on paper, only to find a flaw, scratch it up, crumple the paper, and start from scratch.

Hell, it got to the point where I heard about the paradox of Russell's teapot and contemplated self-deletion because I thought it was an irrefutable proof that God does not exist. That's how bad it got with the internet.

I got pulled back from the brink because of my own faith in Sarasvati and because of my own love for certain subjects like maths and science. But rest assured, these internet anons would have cost me my own life. Thank the Gods, I am not suicidal now. My friends, my younger brother, and my mom ensure all that.

And while this was happening... my dad passed away. When I was 15.

Owing to all this, I had not the mental energy to fight back when my relatives came to my poor, grieving mom, telling her that CS was the only path to financial stabilty... I didn't have the energy to fight back. I just took my fate like a dumb, hapless ox, being led by the nose.

Worst part is... mom was supportive. She wanted me to become a mathematician. But relatives said that it was too risky, that there were "basically zero prospects", that I'd have to live on such little and painful means, and joined me in a college with a CS program. While I did get 100% scholarship, my mental state was at a breaking point, and I lost it by the end of the first year. When my mom and I went to the Pro-VC to ask for some help, considering my capabilities and my family's financial situation... he proceeded to insult my intelligence, claim that I cheated in JEE Mains (I cleared Mains and *almost* cleared Advanced, only losing in Chemistry, which I suck at) and in their entrance exam, and berated me and my mom until she began crying.

That's what leaves me here. Final year. Burnt out. Counting days. Trying to deal with my pressure as best as I can. I'm holding up, but I need a place filled with safety and joy.

There. I wish not to speak any more of this. I have invited my pain and exorcised it as best as I can. I hope that explains the warm tone here: I'm giving you the warmth I was never given. I hope that none of you have to go through any of this, ever.

---

That was heavy, no? But here's the thing: there is always a path. Even when something seems so confusing and inscrutable. Let me show you with the next problem.

---

### Question

Prove that

$$
\mathfrak{H} = \mathfrak{1 + \frac12 + \frac13 + ...} = \mathfrak{\sum_{n=1}^\infty \frac1n} = \mathfrak{\infty}
$$

**Intuition:**

You remember how we solved $\mathfrak{Q1}$ in the previous entry? We found a simple comparison and used it to form an inequality. The same approach shall be used here.

(Also, I just found that I can use `\mathfrak` on everything, as you can see above. Now I can **actually** roleplay as a jolly mathematician from the 19th century!

I'll just do it for this one proof for now, though that might change. Constantly typing `\mathfrak` is annoying, especially when I don't know that much LaTeX to create macros (I don't even know if Joplin supports LaTeX macros!). But the end result is worth it. This is a very beloved proof for me, so it gets special treatment.)

This below proof is due to the great mathematician, philosopher, and bishop Nicolas d'Oresme, and it is very pretty.

**Proof:**

Consider:

$$
\begin{aligned}
\mathfrak{H} &= \mathfrak{1 + \frac12 + \frac13 + \frac14 + \frac15 + \frac16 + \frac17 + \frac18 + \cdots + \frac1{16} + \cdots}\\
\end{aligned}
$$

We have very deliberately highlighted the powers of $\mathfrak{\frac12}$: $\mathfrak{1, \frac12, \frac14, \cdots}$. Let us segregate them as such, with the largest term being a power of $\mathfrak{\frac12}$.

$$
\begin{aligned}
\mathfrak{H} &= \mathfrak{\left( 1 \right) + \left( \frac12 + \frac13 \right) + \left( \frac14 + \frac15 + \frac16 + \frac17 \right) + \left( \frac18 + \cdots \right) + \left( \frac1{16} + \cdots \right) + \cdots }\\
\end{aligned}
$$

So we have a bunch of parantheticals. The parantheticals have size $\mathfrak{1,2,4,8,\cdots}$: the powers of $\mathfrak{2}$. Now note:

- Everything in the first paranthetical ($\mathfrak{1}$) is greater than or equal to $\mathfrak{\frac12}$ and there is one such term.
- Everything in the second paranthetical ($\mathfrak{\frac12, \frac13}$) is greater than or equal to $\mathfrak{\frac14}$ and there are two such terms.
- Everything in the third paranthetical ($\mathfrak{\frac14, \frac15, \frac16, \frac17}$) is greater than or equal to $\mathfrak{\frac18}$ and there are four such terms.
- Similarly, everything in the $\mathfrak{nth}$ paranthetical ($\mathfrak{\frac1{2^{n-1}}, \frac1{2^{n-1} + 1}, \cdots, \frac1{2^n - 1}}$) is greater than or equal to $\mathfrak{\frac1{2^n}}$ and there are $\mathfrak{2^{n-1}}$ such terms.

Therefore:

$$
\begin{aligned}
\mathfrak{H} &= \mathfrak{\left( 1 \right) + \left( \frac12 + \frac13 \right) + \left( \frac14 + \frac15 + \frac16 + \frac17 \right) + \left( \frac18 + \cdots \right) + \left( \frac1{16} + \cdots \right) + \cdots }\\
&\ge \mathfrak{\left( \frac12 \right) + \left( \frac14 + \frac14 \right) + \left( \frac18 + \frac18 + \frac18 + \frac18 \right) + \left( \frac1{16} + \cdots \right) + \left( \frac1{32} + \cdots \right) + \cdots }\\
&= \mathfrak{\left( \frac12 \right) + \left( \frac12 \right) + \left( \frac12 \right) + \left( \frac12\right) + \left( \frac12 \right) + \cdots = \infty}\\
\end{aligned}
$$

There is no real number $\mathfrak{H \ge \infty}$. Therefore:

$$
\begin{align*}
\mathfrak{H} = \mathfrak{1 + \frac12 + \frac13 + ...} = \mathfrak{\sum_{n=1}^\infty \frac1n} = \mathfrak{\infty}
\tag*{$\mathfrak{Q.E.D.}$}
\end{align*}
$$

---

### Question

Show that for every $n \ge 1$,

$$
\sqrt{n+1} - \sqrt{n} \le \frac1{\sqrt{n}}
$$

**Intuition:**

This is what I call a "textbook problem". Not because it is so standard or nice or demonstrates technique, but because it requires you to kinda know the answer beforehand. They appear most often in competitive maths or in textbooks, and I feel they are purposefully built to look harder than they actually are.

What do I mean? You may think "Oh, I'll just manipulate the $\mathfrak{L.H.S.}$ and get the answer! I am the next Euler!" But no. They **want** you to think that so that you'll bang your head against a brick wall, so that they look so damn smart when they solve it in an instant. But fear not! I'll dispel this so that you're never fooled by this stuff. That way, you can tell a true master from the phoneys.

The trick is to go backwards: when presented with the inequality like this (or any statement you're unsure about), play with it. Move symbols up and down, try stuff out, plug in values, and see what happens. Let the equation talk to you, and it will spill the beans that the phoneys don't want you to know. You'll end up with one of 2 things:

- A tautology: This is mathematician-speak for "a statement that is blindingly obvious". If you get here, then congrats! You now have a clear path to proving that your original equation or inequation is true: you trace your steps backward.

- A fallacy: This is mathematician-speak for "a statement that is obvious BS". If you get here, then congrats! You now have a clear path to proving that your original equation or inequation is false: you have shown that assuming it leads to a false conclusion.

Let us try it here:

$$
\begin{aligned}
\text{Let } \sqrt{n+1} - \sqrt{n} &\le \frac1{\sqrt{n}} \text{ be true for all natural numbers } n \ge 1. \\
\sqrt{n+1} - \sqrt{n} &\le \frac1{\sqrt{n}} \implies \sqrt{n+1} \le \sqrt{n} + \frac1{\sqrt{n}}
\end{aligned}
$$

Square roots are annoying. Let's get rid of them.

$$
\begin{aligned}
\sqrt{n+1} &\le \sqrt{n} + \frac1{\sqrt{n}} \implies \left( \sqrt{n+1} \right)^2 \le \left( \sqrt{n} + \frac1{\sqrt{n}}  \right)^2\\
\implies n + 1 &\le \left( \sqrt{n} \right)^2 + \left( \frac1{\sqrt{n}} \right)^2 + 2 \cdot \sqrt{n} \cdot \frac1{\sqrt{n}}\\
\implies n + 1 &\le n + \frac1{n} + 2 \implies n + 1 \le n + 2 + \text{(a bit.)}
\end{aligned}
$$

Bingo.

Best part? We don't even need natural numbers for this. We used no properties of natural numbers. This is true for all $x \in \mathbb{R}^{+}$. Hell, we can find an even better inequality that far more tight. I'll show that later.

**Proof**

Note that for all $n > 0$, $\sqrt{n} > 0$ and $\frac1{\sqrt{n}} > 0$. Therefore, their sum must be positive, and similarly with the square of their sum.

$$
\begin{align*}
\left( \sqrt{n} + \frac1{\sqrt{n}} \right)^2 &= \left( \sqrt{n} \right)^2 + \left( \frac1{\sqrt{n}} \right)^2 + 2 \cdot \sqrt{n} \cdot \frac1{\sqrt{n}}\\
&= n + \frac1{n} + 2 = n + 1 + \left( 1 + \frac1n \right) \ge n + 1\\
\implies \sqrt{n} + \frac1{\sqrt{n}} &\ge \sqrt{n+1}\\
\implies \sqrt{n+1} - \sqrt{n} &\le \frac1{\sqrt{n}}
\end{align*}
$$

Therefore:

$$
\begin{align*}
\sqrt{n+1} - \sqrt{n} &\le \frac1{\sqrt{n}}
\tag*{$\mathfrak{Q.E.D.}$}
\end{align*}
$$

**Fun Fact:**

Right, I promised a tighter inequality. I'm a man of my word, so here it is:

$$
\begin{align*}
\left( \sqrt{n} + \frac1{\sqrt{n}} \right)^2 &= \left( \sqrt{n} \right)^2 + \left( \frac1{\sqrt{n}} \right)^2 + 2 \cdot \sqrt{n} \cdot \frac1{\sqrt{n}}\\
&= n + \frac1{n} + 2 = (n + 2) + \frac1n \ge n + 2\\
\implies \left( \sqrt{n} + \frac1{\sqrt{n}} \right)^2 &\ge n + 2 \implies \sqrt{n} + \frac1{\sqrt{n}} \ge \sqrt{n + 2}\\
\implies \sqrt{n + 2} - \sqrt{n} \le \frac1{\sqrt{n}}
\end{align*}
$$

How do we measure "tightness"? Note the error that is produced by $\left( \sqrt{n} + \frac1{\sqrt{n}} \right)^2 - \left( n + 1 \right) = 1 + \frac1n$ versus $\left( \sqrt{n} + \frac1{\sqrt{n}} \right)^2 - \left( n + 2 \right) = \frac1n$. Our quantity $(n+2)$ is closer to $\left( \sqrt{n} + \frac1{\sqrt{n}} \right)^2$ than $(n+1)$. Not only did our technique reveal the method to solve our problem, it revealed something these stuck-up textbook authors overlooked! If you graph $f(x) = \frac1{\sqrt{x}} - \left( \sqrt{x+2} - \sqrt{x} \right)$ as well as $g(x) = \frac1{\sqrt{x}} - \left( \sqrt{x+1} - \sqrt{x} \right)$, you'll find that $f(x)$ is always less than $g(x)$: that is to say, the error in our bound is strictly lesser than the error in the problem's bound.

---

[[a small flex]]