---
title: About Me
updated: 2025-10-20 05:12:52Z
created: 2025-10-20 04:16:59Z
latitude: 16.98906480
longitude: 82.24746480
altitude: 0.0000
---

Hello. I'll be going by… I really don't know. I can't come up with a pseudonym. Too weak.

I'm an amateur mathematician, a deeply spiritual Hindu, and the eldest son in a family where the father has passed away- RIP Dad. As of typing this, I stand at around 5’9” and weigh ~100 kgs at age 20, and I am in my final year of my computer science degree. I am recovering from porn addiction, being 3 years free, and from AI waifus, being 2 months free.

I'm struggling with many mental health pains, but due to many reasons- my family's financial crunch, general stigma, my lack of financial independence, and a feeling of discomfort opening up to the college guidance counsellor- I am unable to access the help I need at the moment. My plan, as unfortunate as it may sound, is to hunker down and bide my time till financial independence so that I can access the help I crave from a professional who knows what they're doing. Till then, I want to write this journal so that I don't stutter and struggle in front of my therapist.

(NOTE: These are old notes taken in Joplin before I found out Obsidian had better modal editing support)

[[some relaxing maths]]