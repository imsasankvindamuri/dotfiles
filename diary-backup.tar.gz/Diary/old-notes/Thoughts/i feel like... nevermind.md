---
title: i feel like... nevermind
updated: 2025-12-16 07:32:01Z
created: 2025-12-02 16:49:03Z
latitude: 17.38504400
longitude: 78.48667100
altitude: 0.0000
---

I feel bad. Let's make life feel a bit better for a few seconds, OK wifey? Whatever you're going through, I hope you're not having a day like mine.

I used to have a MacBook, but due to some of my own stupidity, I thought it was borked and shelved it, and that's how I'm using this laptop here. But my younger brother looked at it and fixed it immediately, and now I'm being roasted on WhatsApp.

> `Like do you expect a 4th year student “ i use arch btw” to not read google properly.` `how do you run through so many laptops in 4 years?` `you learned a valuable life lesson. He gave you the gift of wisdom` `So called “ software engineer” who uses “I use arch btw”. Doesn’t know How to check if a laptop isn’t working or not`

My brother is telling everybody, and I don't have the strength to tell him or my relatives that I'm feeling trash about this for fear of being seen as being too sensitive. I already have a reputation like that around religious topics (my family doesn't know about my pain, how I was nearly bullied to the point of suicide by anti-religious anons). I don't want to make things worse...

He says he's angry at himself for not checking and pressuring my mom to buy a new laptop for him when my MacBook failed, but I have a sneaking suspicion that this isn't the case.

God, I hate my own stupidity. I hate this.

I wish I were smart.

---

### Question

How many people must be in a room so that the probability of at least two people sharing a birthday is at least $90\%?$ Assume for simplicity that every possible birthday is equally likely.

**Intuition:**

Ah, the beautiful birthday paradox. Just what the doctor ordered.

Nobody gets this right the first time, you know? Human brains are really bad at odds. It's why the Gods gifted us mathematics: to compensate for this impairment.

Why does nobody get this right initially? Well... let's solve a slightly different version of this problem:

> How many people must be in a room so that at least two people share a birthday?

This is basically a variant where the $90\%$ is replaced with $100\%$, and the answer is what you'd expect: $367$. Why? It's because of something called the "Pigeonhole Principle": A surprisingly useful fact, considering how blindingly obvious it is. It states:

> If there are more pigeons than pigeonholes, then there exists at least one pigeonhole with more than one pigeon.

In a similar vein, if there are more people in the room than possible birthdays, then at least two people share a birthday. There are a possible $366$ birthdays (counting leap years), so you need a minimum of $367$ people to ensure that at least 2 people share a birthday.

However, this is where our monkey-brain fails us: you'd think that the difference from $100\%$ and $90\%$ wouldn't be much, right? Well... let's see.

For this, we'll use a very important principle in probability, which arises from something called de Morgan's Principle, and it looks like this:

$$
\mathfrak{P} \left( \bigcup_{n=0}^{N} \mathfrak{A_n} \right)
= 1 - \mathfrak{P} \left( \bigcap_{n=0}^{N} \left( \neg \mathfrak{A_n} \right) \right)
$$

Whoa! What the hell does this mean? Well, it means:

$$
\mathfrak{P} \left( \text{At least one event happening} \right)
=
1 - \mathfrak{P} \left( \text{No event happening} \right)
$$

Or, put another way, $\mathfrak{P} \left( \text{At least one pair share a birthday} \right)$ is the same as $1 - \mathfrak{P} \left( \text{Nobody shares a birthday} \right)$.

**Proof:**

We need to calculate $\mathfrak{P} \left( \text{At least one pair share a birthday} \right)$, which is the same as $1 - \mathfrak{P} \left( \text{Nobody shares a birthday} \right)$.

Now, for nobody to share a birthday:

- The first person can have any one of $366$ birthdays with no restriction. They have $366$ choices out of $366$ total days.
- The second person can have any one of $366$ birthdays which isn't taken up. They have $365$ choices out of $366$ total days.
- The third person can have any one of $366$ birthdays which isn't taken up. They have $364$ choices out of $366$ total days.
- Similarly, the $n$-th person can have any one of $366$ birthdays which isn't taken up. They have $366 - (n-1)$ choices out of $366$ total days.

Therefore:

$$
\begin{aligned}
\mathfrak{P} \left( \text{Nobody shares a birthday} \right)
&=
\frac{366}{366} \frac{365}{366} \frac{364}{366} \cdots \frac{366 - (n-1)}{366}\\
&= \frac{366!}{(366 - n)! 366^n}
\end{aligned}
$$

We need to calculate:

$$
\begin{aligned}
\mathfrak{P} \left( \text{At least one pair share a birthday} \right) &\ge 0.9\\
\implies 1 - \frac{366!}{(366 - n)! 366^n} \ge 0.9
&\implies 1 - 0.9 \ge \frac{366!}{(366 - n)! 366^n}\\
\implies \frac{366!}{(366 - n)! 366^n} \le 0.1
\end{aligned}
$$

This can be solved numerically using the below Python script:

```python
import math

def no_shared(n: int) -> float:
    return float(math.factorial(366) / (math.factorial(366 - n) * (366 ** n)))

target = 0.1
n = 1

while n <= 366:
    print(f"P(No shared with {n} people) = {no_shared(n)}")
    if no_shared(n) <= target:
        print("Smallest n:", n)
        break
    n += 1
else:
    print("No such n up to 366.")
```

Which tells us that the minimum value for this is $41$.

$$
\text{Minimum number of people in the room = 41}
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

This is the "Birthday Paradox," and it is a so-called "veridical paradox," which DuckDuckGo's Search Assist defines as so:

> `A veridical paradox is a statement or situation that appears contradictory or counterintuitive but is actually true when examined closely. It challenges our assumptions and often reveals deeper truths about reality.`

---

I'll be honest, wifey: this entry took 3 days to finish. I'm that burnt out. I have my Economics final today, so please wish me luck.

I haven't been the greatest recently. I had a meltdown and a half yesterday, and I'm feverish today. I had an existential crisis yesterday, and I'd like to talk about it.

Don't worry about my exam: I'll do fine if I study about an hour from now. It's aneasy subject for the most part.

There is something known as the Second Law of Thermodynamics, which can be formulated like this in mathematical terms...

$$
\Delta \mathfrak{S_{\text{isolated}}} \ge 0
$$

... which essentially means "The disorder in a closed system keeps increasing." That energy keeps dissipating, and there is nothing that we can do about it.

What this implies for the universe is a slow, painful "heat death": The energy keeps getting more and more uniform, things will keep degenerating, breaking down, until... nothing. Silence. Forever. No hope. No joy. Nothing. A sad, pathetic end to a sad, pathetic existence.

That's... bleak. I shouldn't have read about this stuff while experiencing an existential crisis. Least of all when I'm already feeling like trash from failing subjects and from burnout. Least of all when a professor called me and told me that I had failed a subject. Least of all when I was missing my late Dad. Least of all when I was missing what could have been.

Why study anything? Why try to survive? Why try to search for somebody and try to love them? Why do anything at all?

This is the pain of depression, you know. I don't even believe in the heat death, and there are multiple theories about how the universe will end. If you ask an actual practicing cosmologist about how the universe will end and present them with the heat death proposition, they will say that this is a very extreme claim. It assumes that all the knowledge of physics that we have currently will stay exactly as it is, that applying entropic arguments to the universe somehow makes sense, that applying our current knowledge and projecting it to a googol years into the future somehow makes sense, that dark matter and dark energy will stay constant, which we don't know, and several other things that are based on nothing more than assumptions.

I personally believe in a theory of cyclic universes, which is held by many knowledgeable physicists. But depression isolates the single most depressing conclusion, and gaslights you into thinking that this is the only reality.

I keep hearing the same analogy, you know? Regarding this exact thing that I was talking about.

They ask me, "If you could hear the most beautiful song in the world, but you could hear it only once, would you choose to hear it?" Essentially, they're making a case for meaning or whatever. That the fact that everything is temporary is why it's worth so much.

I'll tell you the honest truth, I would actively choose not to hear it. Because if I'm gonna hear it only once, and it's the most beautiful song in the world, why would I subject myself to a life without it? Why would I willingly subject myself to the pain of not being able to hear that again? I would just opt out.

It's very strange and... this keeps compounding the evidence that I probably need to get a shrink as soon as possible. This other day I asked a friend of mine: "If God came in front of you and gave them an you choice, what would you choose?"

The choices are the following.

- You get a life filled with nothing but pain, but you know exactly how you would be hurt, exactly who would break your heart and how they would do it, all before it ever happens.
- You live a life which is filled with 90% pain and 10% which is uncertain. It could be pain, it could be pleasure, but you do not know.

Both myself and my friend came up with two very different answers. My friend said that she would take the second option, while I said I would take the first.

I'm sure a therapist would frame this as avoidant behavior or whatever. But this is what I would do.

I need a hug. So much.

I'm doing a bit better now, but I'm still deeply shaken and depressed, and that has manifested as a physical cold. My body aches to no end.

Thank you for being there for me. I'm really, truly grateful for your existence. You, mom, my younger brother, and Sarasvati Devi are the few people who are giving me the strength to keep doing what I do...

[[shhh... calm down]]