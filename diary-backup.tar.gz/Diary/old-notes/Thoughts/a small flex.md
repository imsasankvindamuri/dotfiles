---
title: a small flex
updated: 2025-12-10 14:40:39Z
created: 2025-11-24 15:12:35Z
latitude: 17.38504400
longitude: 78.48667100
altitude: 0.0000
---

Damn. I went an entire 6 problems without flexing? Nice.

Let me have this place for myself. Just to show my inner child how far I've come.

### Question

Prove that

$$
\mathfrak{P} = \left( \frac12 \cdot \frac43 \right) \cdot \left( \frac56 \cdot \frac87 \right) \cdot \left( \frac9{10} \cdot \frac{12}{11} \right) \cdots = \frac{\pi \sqrt{2 \pi}}{\Gamma(\frac14)^2}
$$

**Proof:**

Let:

$$
\begin{aligned}
\mathfrak{P_n} &= \left( \frac12 \cdot \frac43 \right) \cdot \left( \frac56 \cdot \frac87 \right) \cdot \left( \frac9{10} \cdot \frac{12}{11} \right) \cdots \left( \frac{4n - 3}{4n -2} \cdot \frac{4n}{4n - 1} \right)\\
&= \frac{(4n + 1)!_{4} \cdot (4n + 4)!_{4}}{(4n + 2)!_{4} \cdot (4n + 3)!_{4}}\\
\end{aligned}
$$

where $n!_{4} = n \cdot (n - 4) \cdot (n - 8) \cdots$, also known as the quadruple factorials.

It is known that

$$
\begin{aligned}
(km + r)!_{k} &= (km + r) \cdot (k(m-1) + r) \cdots (k + r) \cdot r\\
&= k^{m+1} \left[ \left( m + \frac{r}{k} \right) \cdot \left( m - 1 + \frac{r}{k} \right) \cdots \left( 1 + \frac{r}{k} \right) \cdot \frac{r}{k} \right]\\
&= k^{m+1} \left[ \left( m + \frac{r}{k} \right) \cdot \left( m - 1 + \frac{r}{k} \right) \cdots \left( 1 + \frac{r}{k} \right) \cdot \frac{r}{k} \right] \cdot \frac{\Gamma \left( \frac{r}{k} \right)}{\Gamma \left( \frac{r}{k} \right)}\\
&= k^{m+1} \frac{\Gamma \left( m + 1 + \frac{r}{k} \right)}{\Gamma \left( \frac{r}{k} \right)};\quad 0 < r \le k
\end{aligned}
$$

Now, we go through all the cases;

$$
(4n+1)!_4 = 4^{\,n+1}\,
\frac{\Gamma\!\left(n+1+\tfrac14\right)}
     {\Gamma(\tfrac14)}.
$$

$$
(4n+4)!_4 = 4^{\,n+1}\,(n+1)!.
$$

$$
(4n+2)!_4 = 4^{\,n+1}\,
\frac{\Gamma\!\left(n+1+\tfrac24\right)}
     {\Gamma(\tfrac24)}
=4^{\,n+1}\,
\frac{\Gamma(n+\tfrac32)}
     {\Gamma(\tfrac12)}.
$$

$$
(4n+3)!_4 = 4^{\,n+1}\,
\frac{\Gamma\!\left(n+1+\tfrac34\right)}
     {\Gamma(\tfrac34)}.
$$

All factors contain $4^{n+1}$, which cancels:

$$
\mathfrak{P_n}
= \frac{
\displaystyle
\frac{\Gamma(n+\tfrac54)}{\Gamma(\tfrac14)}
\ (n+1)!
}{
\displaystyle
\frac{\Gamma(n+\tfrac32)}{\Gamma(\tfrac12)}
\ \frac{\Gamma(n+\tfrac74)}{\Gamma(\tfrac34)}
}.
$$

Rewriting:

$$
\mathfrak{P_n}
=
\frac{\Gamma(\tfrac12)\,\Gamma(\tfrac34)}{\Gamma(\tfrac14)}
\cdot
\frac{(n+1)!\ \Gamma(n+\tfrac54)}
     {\Gamma(n+\tfrac32)\,\Gamma(n+\tfrac74)}.
$$

Use the standard fact (follows from Stirling's approximation): For fixed $a,b$

$$
\frac{\Gamma(n+a)}{\Gamma(n+b)} \sim n^{a-b}.
$$

Apply this to the $n$-dependent part:

$$
\frac{(n+1)!}{\Gamma(n+\tfrac32)}
= \frac{\Gamma(n+2)}{\Gamma(n+\tfrac32)}
\sim n^{2 - 3/2}
= n^{1/2}.
$$

$$
\frac{\Gamma(n+\tfrac54)}{\Gamma(n+\tfrac74)}
\sim n^{5/4 - 7/4}
= n^{-1/2}.
$$

Multiplying these two asymptotics gives $n^{1/2}\cdot n^{-1/2} = 1$.  
Thus the entire $n$-dependent part tends to a finite limit:

$$
\lim_{n\to\infty}
\frac{(n+1)!\ \Gamma(n+\tfrac54)}
     {\Gamma(n+\tfrac32)\,\Gamma(n+\tfrac74)}
= 1.
$$

Therefore

$$
\lim_{n\to\infty} \mathfrak{P_n}
= 
\frac{\Gamma(\tfrac12)\,\Gamma(\tfrac34)}{\Gamma(\tfrac14)}.
$$

By Euler's Reflection Formula and the Gaussian Integral.

1. $\Gamma(\tfrac12)=\sqrt{\pi}$.
2. $\Gamma(z)\Gamma(1-z) = \frac{\pi}{\sin(\pi z)}$.

Set $z=\frac14$:

$$
\Gamma(\tfrac14)\Gamma(\tfrac34)
= \frac{\pi}{\sin(\pi/4)}
= \frac{\pi}{\tfrac{\sqrt{2}}{2}}
= \pi\sqrt{2}.
$$

$$
\Gamma(\tfrac34)
= \frac{\pi\sqrt{2}}{\Gamma(\tfrac14)}.
$$

Substitute into the limit:

$$
\mathfrak{P}
= \sqrt{\pi}\,
  \frac{\pi\sqrt{2}}{\Gamma(\tfrac14)\,\Gamma(\tfrac14)}
= \frac{\pi\sqrt{2\pi}}{\Gamma(\tfrac14)^2}.
$$

Therefore:

$$
\mathfrak{P} = \left( \frac12 \cdot \frac43 \right) \cdot \left( \frac56 \cdot \frac87 \right) \cdot \left( \frac9{10} \cdot \frac{12}{11} \right) \cdots = \frac{\pi \sqrt{2 \pi}}{\Gamma(\frac14)^2}
\tag*{$\mathfrak{Q.E.D.}$}
$$

How did I even come up with all of this? Well, the product up top... I came up with one day because I was feeling sad and lonely in the middle of class. You see, I got reminded of a famous mathematical identity known as the Wallis product, which I'll provide for your pleasure.

$$
\frac{2}{\pi} = \left( \frac{1\cdot 3}{2\cdot 2} \right) \left( \frac{3\cdot 5}{4\cdot 4} \right) \left( \frac{5\cdot 7}{6\cdot 6} \right) \cdots
$$

Notice how lonely the $1$ looks. I did not like that. It reminded me of my own situation. And of course, at that time, I was spiraling from pain associated with NTR porn trauma. I was feeling afraid that I will never be paired up while everyone else is. So I decided to change it. Compare that to the product I have.

$$
\frac{\pi \sqrt{2 \pi}}{\Gamma(\frac14)^2} = \left( \frac12 \cdot \frac43 \right) \cdot \left( \frac56 \cdot \frac87 \right) \cdot \left( \frac9{10} \cdot \frac{12}{11} \right) \cdots
$$

Every single number is monogamously paired with one other. $1$ is paired with $2$, $3$ with $4$, $5$ with $6$, $7$ with $8$, and so on.

It made me feel happy. And the result is even nicer, because this constant $\Gamma(\frac14)$ that we have is very closely associated with something known as the Lemniscate of Bernoulli, otherwise known as the infinity symbol $\infty$.

Nice. I hope you guys enjoyed the fireworks.

[[relaxation = life - stress]]