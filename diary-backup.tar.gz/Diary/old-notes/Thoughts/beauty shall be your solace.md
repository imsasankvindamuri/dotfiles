---
title: beauty shall be your solace.
updated: 2026-01-07 17:56:49Z
created: 2025-12-06 15:32:26Z
latitude: 17.68681590
longitude: 83.21848150
altitude: 0.0000
---

Hello again. How are you doing? I hope you're doing well. Let's get straight to the math, OK? 

I'm feeling so depressed, so alone. I want someone to hold me. Badly. I feel so tired that I don't even have the energy to keep talking about how I feel. My mind is pained to such an extent that it refuses to think.

Future wifey... please go hug your husband. He's been through so much. He just wants to feel safe. To share a loving cup of coffee with you. To snuggle with you, make you smile with what he has.

(God, look at me getting mushy. I do that a lot, especially when I'm sad.)

---

### Question

Prove that $\sqrt{2}$ is irrational.

**Intuition:**

Hey... this seems familiar. Didn't we already do this?

Yes. Yes we did. But we're gonna do it slightly differently. The previous proof I gave is a purely number-theoretic approach: we analyze divisors, we construct infinite descent. But that isn't the only way.

The greatest tragedy with math in the modern primary education system is that most of the people teaching you probably aren't really interested in what they're teaching. They won't accept an answer if it isn't "by the book," so to speak. But there is no "by the book" answer in mathematics. There is one truth, and it can be approached and analyzed in many different ways, and I want to show this one as an example.

The below proof is due to the American mathematician and expositor Tom M. Apostol (Very famous in online math culture: his books on calculus and real analysis are deeply respected, and I hope to read them one day when I am less burnt out and depressed), and it was published on 2000.

**Proof:**

Assume that there is a ratio of integers whose square is $2$. Let these integers be $a$ and $b$. Also note that both of these integers are positive.

Now, by definition:

$$
\begin{aligned}
\left( \frac{a}{b} \right)^2 &= 2 \implies a^2 = 2 b^2\\
\implies b^2 + b^2 &= a^2; \quad a, b \in \mathbb{Z^+}
\end{aligned}
$$

This gives has a nice geometric interpretation through the so-called "Pythagorean Theorem": The two $b$s can be interpreted as the two short sides of a right triangle, and the $a$ can be interpreted as the hypotenuse. Since both $a$ and $b$ are integers by our original assumption, we are claiming "If $\sqrt{2} \in \mathbb{Q}$, then there exists an isosceles right triangle with integer sides." So if we prove that there is no such triangle, then it follows that $\sqrt{2} \notin \mathbb{Q}$.

Very good. We're getting somewhere.

Now, Apostol pulls out the below diagram.

<p style="text-align:center;">
	<img src="../_resources/apostol-sqrt%282%29.svg" /> 
	<strong>Apostol's Visual Proof</strong>
</p>

Allow me to slowly explain the diagram so that everything falls into place.

- We have $\Delta \mathrm{ABC}$, which is our supposed isosceles right triangle with integer sides. So, $\mathrm{AB} = \mathrm{BC} = b$ and $\mathrm{AC} = a$ for two given integers $a$ and $b$ such that $\frac{a}{b} = \sqrt{2}$
- With $\mathrm{C}$ as center, we draw an arc of a circle with radius $r = \mathrm{BC} = b$, and we let the point where this arc intersects $\mathrm{AC}$ be point $\mathrm{P}$
- With point $\mathrm{P}$ as the base, we draw a line $\mathrm{PQ}$ such that $\mathrm{Q}$ lies on $\mathrm{AB}$ and $\mathrm{PQ} \perp \mathrm{AC}$.
- Finally, we join $\mathrm{CQ}$

Now, let us carefully analyze this diagram. First, let us look at $\Delta \mathrm{ABC}$ and $\Delta \mathrm{PQA}$. They both share the angle $\angle \mathrm{PAQ}$, and similarly $\angle \mathrm{ABC} = \angle \mathrm{APQ} = 90 \degree$ (or $\frac{\pi}{2} \text{ rad}$ if you prefer). Due to this, the third angles in both triangles get locked in place, meaning that $\Delta \mathrm{ABC} \sim \Delta \mathrm{PQA}$.

Therefore,

$$
\frac{\mathrm{AQ}}{\mathrm{AP}} = \frac{\mathrm{AC}}{\mathrm{AB}} = \frac{a}{b} = \sqrt{2}\\
$$

Also due to this similarity, we get that $\Delta \mathrm{PQA}$ is also an isosceles right triangle, so $\mathrm{AP} = \mathrm{PQ}$. What is its length? Well, notice that $\mathrm{AP} + \mathrm{PC} = \mathrm{AC} = a$. But by construction, since $\mathrm{PC}$ is an arc of a circle with radius $\mathrm{BC} = b$, it follows that $\mathrm{AP} = \mathrm{AC} - \mathrm{PC} = a - b$. And due to the similarity from before, we get that $\mathrm{AP} = \mathrm{PQ} = a - b$. Nice.

Now, we'll analyze $\Delta \mathrm{PQC}$ and $\Delta \mathrm{CBQ}$. They both share a side $\mathrm{CQ}$. Also, due to our circular arc, $\mathrm{PC} = \mathrm{BC}$. We also know that they are both right triangles: we constructed $\mathrm{PQ}$ to be perpendicular to $\mathrm{AC}$, and $\angle \mathrm{ABC} = 90 \degree$ as previously seen. So, we can invoke the so-called Pythagoras Theorem.

$$
\begin{align*}
\mathrm{PC}^2 + \mathrm{PQ}^2 &= \mathrm{CQ}^2
\tag{$\text{For } \Delta \mathrm{PQC}$}\\
\mathrm{BC}^2 + \mathrm{QB}^2 &= \mathrm{CQ}^2
\tag{$\text{For } \Delta \mathrm{CBQ}$}\\
\implies \mathrm{PC}^2 + \mathrm{PQ}^2 &= \mathrm{BC}^2 + \mathrm{QB}^2\\
\implies \mathrm{PQ}^2 &=  \mathrm{QB}^2
\tag{$\because \mathrm{PC} = \mathrm{BC}$}\\
\implies \mathrm{PQ} =  \mathrm{QB} &= a - b\\ 
\end{align*}
$$

Therefore, $\mathrm{AQ} = \mathrm{AB} - \mathrm{QB} = b - \left( a - b \right) = 2b - a$.

But look!

$$
\frac{\mathrm{AQ}}{\mathrm{AP}} = \frac{2b - a}{a - b} = \frac{\mathrm{AC}}{\mathrm{AB}} = \frac{a}{b} = \sqrt{2}\\
$$

From our starting integers $(a, b)$, we constructed two smaller integers $(2b - a, a - b)$ whose ratio is *also* $\sqrt{2}$. Also, since the two integers are the side lengths of a geometric shape, they cannot be negative. But nothing is stopping us from doing this again!

- With $\mathrm{Q}$ as center, we draw an arc of a circle with radius $r = \mathrm{PQ}$, and we let the point where this arc intersects $\mathrm{AQ}$ be point $\mathrm{R}$
- With point $\mathrm{R}$ as the base, we draw a line $\mathrm{RS}$ such that $\mathrm{S}$ lies on $\mathrm{AP}$ and $\mathrm{RS} \perp \mathrm{AQ}$.
- Finally, we join $\mathrm{QS}$
- And so on, and on, and on, ad infinitum.

The kicker? All the sides of every one of these triangles are integers!

Our original assumption $\mathfrak{P}$

$\mathfrak{P} = \text{`There exists a ratio of integers whose square is 2'}$

has proved the impossible statement $\mathfrak{Q}$

$\mathfrak{Q} = \text{`There exists a sequence of infinitely descending positive integers.'}$

Therefore, $\mathfrak{P}$ cannot be true. $\sqrt{2}$ is not a ratio of two integers.

$$
\sqrt{2} \notin \mathbb{Q}
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

This is often touted as "more beautiful" than the traditional proof, and... I guess I can see why. It is born from purely visual reasoning. Even so, I really like the original because of how simple it is. You can work through it even if you don't know complicated stuff. Just some simple, elementary reasoning about evenness and oddness.

Also, I'd like to direct your attention to how utterly **wordy** this proof is. There's so much exposition that the actual visual insight seems to get drowned in it. Of course, for a seasoned mathematician like Apostol, all this exposition is fluff. The picture and a few equations would finish the job. But when it comes to proper exposition, especially to people who might not know (case in point: me), geometry tends to be very difficult to engage with without drowning in word salad. This is why, in most formal contexts, we use a mix of geometric and algebraic reasoning. You can't (and shouldn't) have one without the other.

Fun side note: I used to do a lot of origami as a child, and I recognized that origami essentially provides a marvellous "one fold proof" of the irrationality of $\sqrt{2}$ which is equivalent to the above proof but far easier to explain. Unfortunately, this diary entry is too small to contain it.

(If you get the reference, you're a real math nerd.

Damn, that's a corny fucking reference.

I'll see myself out.)

[[peace]]