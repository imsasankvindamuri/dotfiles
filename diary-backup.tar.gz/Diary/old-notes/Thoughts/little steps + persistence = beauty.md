---
title: little steps + persistence = beauty
updated: 2026-01-07 17:59:17Z
created: 2025-12-22 07:33:45Z
latitude: 17.54663100
longitude: 78.21313980
altitude: 0.0000
---

Hello... I hope you are doing well, future wifey. Also, have you taken coffee or tea? Any drink that relaxes you? You really should. Take whatever beverage makes you feel right at home: preferably, take something warm.

Today's the first day I'm attending in my 8th semester. Not feeling great. If I were younger, I'd be ecstatic: I only have 3 classes per week! But... responsibilities are piling up, I'm feeling depressed, and the pull of the AI waifus is feeling so strong. I'm trying my best, but I'm stumbling.

My waistline also grew significantly. Pants that used to be a nice fit on me are a bit tight now. My compulsive eating of junk food and my propensity to sit in place are compounding my weight. I think I'm ~107 Kgs at a little under 6 feet (5 feet 9 inches? IDK), and... I don't know. I can't even bring myself to care about this.

Hell, my palms ache as I type this. That's how tired and drained I feel right now.

But enough of that. Let us spend what little time we have with each other doing something that is beautiful.

---

### Question

Can you put a rough bound on $\pi?$

**Intuition:**

"Well, that's easy!" I hear you cry. "$\pi$ is approximately $3.1415...$, so our bounds are that $3 < \pi < 4$. QED." But how do you know that? "Because we calculated $\pi$ accurate to many decimals!"

But this is circular logic: the reason we know $\pi$ to so many decimal places *is* because we're able to bound it above and below by other numbers. So how do we do it?

There are many ways. We can derive it experimentally with accurate measurements, we can use infinite sums which have been cut off at a certain point (which is the most common approach), and so on. What we'll see today is a common, ancient method called, quite aptly, the "method of exhaustion."

Basically, we will exploit the Pythagorean theorem and the area formula for a circle ($\text{Area of circle} = \pi r^2$) to trap the area of a circle between two other shapes whose areas are easy to calculate. For our case, we will trap the circle between two relatively simple but nontrivial shapes: a square on the outside and a hexagon in the inside. We will also exploit the fact that a regular hexagon can be chopped up into 6 equilateral triangles.

As usual, you are free to try this on your own. Otherwise, just sit back and enjoy the derivation.

**Proof:**

Consider the below diagram.

<p style="text-align:center;">
	<img src="../_resources/method-of-exhaustion.svg" /> 
	<strong>The Method of Exhaustion</strong>
</p>

- We have a circle with centre $\mathrm{O}$ and radius $\mathrm{OA}$. For convenience, we will this length $\mathrm{OA} = r$.
- Around the circle, we have the large square $\mathrm{PQRS}$, and inside, we have the regular hexagon $\mathrm{ABCDEF}$.
- We also have construction lines $\mathrm{OB}$, $\mathrm{OA}$, and $\mathrm{BX}$ in orange such that $\angle OXB = \angle AXB = 90 \degree$ (or $\frac{\pi}{2} \text{ rad}$).

Now note that since the hexagon is regular, every angle in the hexagon must be $120 \degree$, meaning that if we bisect every angle, we will get 6 equilateral triangles. You can try to fill in the details yourself if you please, but it's visually obvious, I feel. Hell, if you really wanna be convinced, you can make a paper regular hexagon and do it physically! It's fun, at least for me. At any rate, this means that $\mathrm{\Delta OBA}$ is an equilateral triangle.

What this means for us is that the height $\mathrm{BX}$ cuts the radius $r$ into 2 equal halves. Therefore, $\mathrm{OX} = \frac{r}2$.

(Again, you guys can fill in the details if you are adventurous: it involves congruent triangles. But the point here if the **insight**, not the machinery. I'll wade through machinery sometimes, but pay mind to the ideas, not the lever-pushing.

A computer can push levers and invoke obscure theorems. Only a human can *think.* It's our survival advantage, it's why we're the dominant species on Earth, and it is a gift given to us by Sarasvati Devi. Training it is every human's duty.)

By the "Pythagorean" Theorem (read: The Baudhayana Theorem),

$$
\mathrm{OB^2 = OX^2 + XB^2}\\
\implies r^2 = \left( \frac{r}2 \right)^2 + \mathrm{XB^2} \implies r^2 = \frac{r^2}4 + \mathrm{XB^2}\\
\implies \mathrm{XB^2} = \frac{3r^2}4 \implies \mathrm{XB} = \frac{r\sqrt{3}}{2}
$$

Therefore, the area of one of these equilateral triangle is $\frac12 \text{(base)(height)}$, which is $\frac12 \mathrm{OA \cdot BX} = \frac12 \cdot r \cdot \frac{r\sqrt{3}}{2} = \frac{\sqrt{3}}{4} r^2$. There are six of these that make up the hexagon, so its area is $6 \cdot \frac{\sqrt{3}}{4} r^2 = \frac{3\sqrt3}{2} r^2$. Nice.

Simultaneously, since $\mathrm{PQRS}$ is a square, $\mathrm{PQ = AD} = 2r$, so the area of the square is $4 r^2$.

Now,

$$
\text{Area of ABCDEF} < \text{Area of circle} < \text{Area of PQRS}\\
\implies \frac{3\sqrt3}{2} r^2 < \pi r^2 < 4 r^2\\
\implies \frac{3\sqrt3}{2} < \pi < 4
$$

Which was precisely what we wished to find.

$$
\pi \in \left( \frac{3\sqrt3}{2}, 4 \right)
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

Numerically, $\frac{3\sqrt3}{2} \approx 2.5980...$, so our bound is pretty nice for the simple tools we used. Even so, this simple, almost naive bounding of $\pi$ can be improved if we are simply persistent. Archimedes used a similar argument like this but with perimeters, and he trapped $\pi$ between 2 96-sided shapes to get this astonishing bound:

$$
\frac{223}{71} < \pi < \frac{22}{7}
$$

Seem familiar? This is the origin of the famous $\frac{22}{7}$ approximation for $\pi$.

In the Book of Kings in the Old Testament, we find one of the early approximation of $\pi$:

> And he made a molten sea, ten cubits from the one brim to the other; it was round all about, and his height was five cubits, and a line of thirty cubits compassed it round about.
>
> 1 Kings 7:23, King James Bible

Basically, it implies $\pi \approx 3$, which is true!

The Sulba Sutras give an approximate solution to "The Quadrature of the Circle"; basically constructing a square with the same area as a given circle:

> To transform a circle into a square, the diameter is divided into eight parts; one [such] part after being divided into twenty-nine parts is reduced by twenty-eight of them and further by the sixth [of the part left] less the eighth [of the sixth part].
>
> Baudhayana Sulba Sutra, 2.10

In less words, it implies

$$
\pi \approx 4 \left( \frac{7}{8}+\frac{1}{8\cdot29}-\frac{1}{8\cdot29\cdot6}+\frac{1}{8\cdot29\cdot6\cdot8} \right)^2 \approx 3.088...
$$

This was encoded almost **2 centuries** before Archimedes, and is still astonishingly accurate. Rounding off, we get that $\pi \approx 3.1$, which is only one decimal short of what Archimedes derived. Considering that all they used was rope and their own minds... it shows much both about their sophistication and the willingness to work slowly, carefully with the tools they had.

Indeed, these examples show us a very important lesson: even things that are so difficult to understand and work with can be solved. Not by trying to shatter it all at once, but by slowly, persistently taking small steps. In other words, little steps + persistence = beauty.

[[a small cool thing]]