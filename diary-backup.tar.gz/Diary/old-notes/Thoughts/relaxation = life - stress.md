---
title: relaxation = life - stress
updated: 2025-12-16 07:27:24Z
created: 2025-11-25 04:58:33Z
latitude: 17.38504400
longitude: 78.48667100
altitude: 0.0000
---

Welcome back to this mathematician's dwelling. I'd like to thank all of you for being here. I can only assume that both of you are going through life, anthropology major and future therapist. And to my future wifey... I'm sure you had a long day.

So today, we'll have another few relaxing problems.

I'll be honest with you guys: I love the simple questions far more than the difficult questions, like the $\Gamma(\frac14)$ from my flex. Why? Because the ones that just need logic, that are a joy to solve with others... they are the ones that bring family and friends together. That make you feel like you're at home.

Here's a challenge you guys can try: Take the Aces, Queens, Kings, and Jacks out of a 52 card deck and challenge yourself to make a $4 \times 4$ grid that has the following constraints:

- Each row must have exactly one Heart, Spade, Club, and Diamond, as well as exactly one King, Queen, Jack, and Ace.
- Each column must have exactly one Heart, Spade, Club, and Diamond, as well as exactly one King, Queen, Jack, and Ace.
- Both diagonals must have exactly one Heart, Spade, Club, and Diamond, as well as exactly one King, Queen, Jack, and Ace.

Knock yourselves out. I showed this to my relatives in a family gathering, and myself, my younger brother, and two cousins spent quite some time trying to solve this, and in the end, we had to look up the answer.

Here's the fun part about the entire interaction. One of the cousins is a successful programmer with a 60 lakh per annum income, and moreover, he is a B.Arch graduate from IIT Kharagpur (Future wifey will know exactly who I'm talking about). We did this exact thing with Uno cards and it was just me, my younger brother, and these two cousins stuck constantly moving cards up and down while the rest of the family just looked at us. 

The IIT cousin walked in thinking he's going to ace the problem immediately. And then all four of us got our asses handed back to us by how difficult the problem was. At one point he even declared it was impossible until I looked up the solution and showed it to him.

Anyway, let's begin.

---

### Question

I have with me 2 coins: a biased coin and a fair coin. I do not know which coin is biased, and in what way it is biased: just that one of my two coins is biased. Is it possible to still use both coins to construct a perfectly fair two-player game? That is, is it possible to use both coins to make a two player game where $\mathfrak{P}(\text{I win}) = \mathfrak{P}(\text{You win}) = \frac12$?

**Intuition:**

Dear God, this a weird problem. Two coins, indistinguishable, and one is biased but we don't know which or how much? We have nothing to go off of! What the hell do we do?

Well... a good practice in problem solving is to give names and solve simpler versions of problems. So let's name the important things. Let us call the biased coin $B$ for "biased" and the fair coin $F$ for "fair." We do not know which coin is $B$ and which is $F$, but we **do** know that exactly one of our two coins is $B$ and the other is $F$.

We also don't know how much $B$ is biased, and in which direction it is biased. It could give us heads more often, or tails more often. We don't know. Nevertheless, let $\mathfrak{p}$ be the probability of getting heads on $B$. So naturally, the probability of getting tails is just the probability of not getting heads. So the probability of getting tails is $1 - \mathfrak{p}$.

OK... we got somewhere. But what do we do now? A good practice with these probability problems is to try and map out our sample space, or the possible outcomes. Let's do that, OK?

What's the probability of getting two heads? Well, both the biased coin and the fair coin need to come up heads. We write that as $\mathfrak{P}(\text{(B = H)} \cap \text{(F = H)})$. They outcomes of each individual coin is independent of the other, so we can split them as so:

$$
\begin{aligned}
\mathfrak{P}(\text{(B = H)} \cap \text{(F = H)})
&= \mathfrak{P}(\text{B = H}) \cdot \mathfrak{P}(\text{F = H})\\
&= \mathfrak{p} \cdot \frac12 = \frac{\mathfrak{p}}{2}
\end{aligned}
$$

Similarly, the probability of getting both tails is as so:

$$
\begin{aligned}
\mathfrak{P}(\text{(B = T)} \cap \text{(F = T)})
&= \mathfrak{P}(\text{B = T}) \cdot \mathfrak{P}(\text{F = T})\\
&= \left( 1 - \mathfrak{p} \right) \cdot \frac12 = \frac{1 - \mathfrak{p}}{2}
\end{aligned}
$$

I'll let you guys fill in the details for $\mathfrak{P}(\text{(B = H)} \cap \text{(F = T)})$ and $\mathfrak{P}(\text{(B = T)} \cap \text{(F = H)})$. At any rate, we'll get a table like this.

| Need                                  | Symbol                                                   | Probability                 |
|-------------------------------------------|-----------------------------------------------------------|-----------------------------|
| Both give Heads                           | $\mathfrak{P}((B = H) \cap (F = H))$                     | $\frac{\mathfrak{p}}{2}$    |
| Both give Tails                           | $\mathfrak{P}((B = T) \cap (F = T))$                     | $\frac{1 - \mathfrak{p}}{2}$ |
| Biased gives Heads, Fair gives Tails      | $\mathfrak{P}((B = H) \cap (F = T))$                     | $\frac{\mathfrak{p}}{2}$    |
| Biased gives Tails, Fair gives Heads      | $\mathfrak{P}((B = T) \cap (F = H))$                     | $\frac{1 - \mathfrak{p}}{2}$ |

Do you see what I see?

**Proof:**

Yes. It is possible. Flip both coins, and set the below win conditions:

- Player 1 wins if both results are the same.
- Player 2 wins if they're both different.

In this setup,

$$
\mathfrak{P}(\text{Player 1 wins}) = \mathfrak{P}(\text{Player 2 wins}) = \frac12
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

This is similar to something known as "von Neumann de-biasing", which was a trick developed by John von Neumann to solve an interesting problem:

> How do you get an unbiased source of bits from a biased source? That is, if you have a biased source of bits with probability $\mathfrak{p}$ of giving you a $1$, how do you extract a fair string of bits from that?

The solution? Use the source to get two bits, then apply the following rule:

- $10$ is treated as $1$
- $01$ is treated as $0$
- Any other result is discarded, and a new pair is drawn up

Essentially, it boils down to the following.

> If the two bits were different, then take the first result as the required result. Otherwise, discard and try again.

Why does this work? Let's draw up a table!

| Need | Symbol             | Probability                      |
| ---- | ------------------ | -------------------------------- |
| $11$ | $\mathfrak{P}(11)$ | $\mathfrak{p}^2$                 |
| $10$ | $\mathfrak{P}(10)$ | $\mathfrak{p}(1 - \mathfrak{p})$ |
| $01$ | $\mathfrak{P}(01)$ | $(1 - \mathfrak{p})\mathfrak{p}$ |
| $00$ | $\mathfrak{P}(00)$ | $(1 - \mathfrak{p})^2$           |

Notice that $10$ and $01$ have the same probability. We have made an unbiased source of bits from a biased source!

In practice, we use more advanced techniques to remove bias, but this toy example is the mother of all those methods. Why do we not use this? If we have $N$ bit pairs, on average:

$$
\begin{aligned}
\text{\# bit pairs we will reject} &\approx N \left( \mathfrak{p}^2 + (1 - \mathfrak{p})^2 \right)\\
\implies \text{\% bit pairs we will reject} &\approx \left( \mathfrak{p}^2 + (1 - \mathfrak{p})^2 \right)\\
\end{aligned}
$$

What this means is that if the probability of getting a $1$ is particularly low, then you'd reject a **massive** amount of data, which is very wasteful. For example, if your biased source of information has a $10\%$ chance of giving you a $1$, then on average, you'd reject $100\% \cdot \left( 0.1^2 + 0.9^2 \right) = 82\%$ of your bit pairs! What a waste!

Also, what we did in our problem is known as an "XOR" (short for "exclusive OR"), represented by $\oplus$. Essentially, if we have 2 bits $p$ and $q$, $p \oplus q$ is $1$ if and only if exactly one of $p$ or $q$ is $1$. It's not generally used to extract randomness, but it works here due to the nice symmetry that $\frac12 = 1 - \frac12$. What we've proven, indirectly, is that if $p$ is a fair stream of bits, then $p \oplus \left( \text{any stream of bits} \right)$ is also fair, so long as both streams are independent of each other.

---

### Question

Prove that there is no ratio of integers whose square is $2$.

**Intuition:**

A classic. Needs no introduction. The crown that sits on Sarasvati's brow.

For this, we need a few small tools. You can verify them yourselves, but I'll just state them as a given here. You guys can try to reason through them as a nice warmup:

> **Fact 1:** If $a$ is even, then so is $a^2$.
> **Fact 2:** If $a^2$ is even, then so is $a$.
> **Fact 3:** If $b$ is odd, then so is $b^2$.
> **Fact 4:** If $b^2$ is odd, then so is $b$.

This is, of course, assuming that all of them are integers.

Fact 1 and Fact 3 are easy to work through: just algebra. But Fact 2 and Fact 4 are more subtle. We know them intuitively, but a nitpicky greybeard may poke you for a proof. Don't worry, though: I won't.

(A small hint for you guys, if you want to prove Fact 2 and Fact 4: think about evenness and oddness. Write out possibilities and verify case-by-case.)

We will perform what is known in the business as a "Proof by Infinite Descent." What does that mean? Well, it means the following:

> If I assume the statement $\mathfrak{P}$, then I can use logical deductions to prove the statement $\mathfrak{Q}$
>
> $\mathfrak{Q} = \text{`There exists a sequence of infinitely descending positive integers.'}$

But this is clearly absurd! There exists a smallest positive integer; the number $1$. You can't keep counting down **and** stay positive forever! Since our assumption $\mathfrak{P}$ led us to the absurd $\mathfrak{Q}$ through purely logical deductions, it follows that our original assumption was false. Hence, we prove the impossibility of $\mathfrak{P}$.

Sit back, and let the math calm you down. It's midnight, everyone's asleep, Linux Mint is going through a system update as I type this. For just a few moments, let us focus on this.

**Proof:**

Assume that there is a ratio of integers whose square is $2$. Let these integers be $a$ and $b$. Also note that both of these integers are positive.

Now, by definition:

$$
\begin{aligned}
\left( \frac{a}{b} \right)^2 &= 2 \implies a^2 = 2 b^2\\
&\implies a^2 = 2 \cdot (\text{an integer})\\
&\implies a^2 \text{ is even}\\
&\implies a \text{ is even}
\end{aligned}
$$

Alright. Since $a$ is even, we can write it in the form $2 \cdot (\text{an integer})$, where the integer is positive and strictly less than $a$. Let this new number be $a'$. Therefore, $a = 2a'$ by definition.

$$
\begin{aligned}
a^2 &= 2 b^2 \implies (2a')^2 = 2 b^2\\
&\implies 4 a'^2 = 2 b^2 \implies 2 a'^2 = b^2\\
&\implies b^2 \text{ is even}\\
&\implies b \text{ is even}
\end{aligned}
$$

Since $b$ is even, we can write it in the form $2 \cdot (\text{an integer})$, where the integer is positive and strictly less than $b$. Let this new number be $b'$. Therefore, $b = 2b'$ by definition.

But look!

$$
\begin{aligned}
\left( \frac{a}{b} \right)^2 = 2 \implies \left( \frac{2a'}{2b'} \right)^2 = 2\\
\implies \left( \frac{a'}{b'} \right)^2 = 2
\end{aligned}
$$

We have looped back! From the integers $(a,b)$, we have found two strictly smaller integers $(a',b')$ such that $\left( \frac{a'}{b'} \right)^2 = 2$. We can repeat the process and get two even smaller positive integers (let's call them $a''$ and $b''$), from which we can get even smaller positive integers, and so on ad infinitum!

Our original assumption $\mathfrak{P}$

$\mathfrak{P} = \text{`There exists a ratio of integers whose square is 2'}$

has proved the impossible statement $\mathfrak{Q}$

$\mathfrak{Q} = \text{`There exists a sequence of infinitely descending positive integers.'}$

Therefore, $\mathfrak{P}$ cannot be true. $\sqrt{2}$ is not a ratio of two integers.

$$
\sqrt{2} \notin \mathbb{Q}
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

This proof convinced me that the universe is fundamentally ordered. That we live in a fundamentally beautiful world. That Brahman is real.

I was utterly dumbfounded when I saw this in my government-prescribed NCERT math textbook.

This above proof was supposedly given by a great philosopher and mathematician named Hippasus of Metapontum. This man was a member of the Pythagorean sect, a secretive group of mathematicians in Ancient Greece who held many religious beliefs about numbers. Many say that he was drowned for this proof, but from what I gather, he was drowned for revealing the existence of irrational numbers to the outside world. This was scandalous at the time: the Pythagoreans believed that everything can be expressed as a ratio of integers, but $\sqrt{2}$ is demonstrably not a ratio! Revealing this "dark secret" to the uninitiated was seen as sacrilege, and so Hippasus was taken to the sea and promptly drowned.

Back when I used to be in those debate forums as a child, trying desperately to defend my right to believe against trolls who don't listen to reason, this story was often weaponized against me to show how dumb religion is and how belief in God "turns you to a murder hobo," as they so eloquently put it.

Because obviously that is the secular-humanist thing to do. To pick on a child who is desperately trying to defend his own beliefs. A child who wasn't even trying to convert other people. A child who was expressing that he has a right to believe and that the beauty of mathematics is evidence of God to him.

That aside, $\sqrt{2}$ was well known even before the Greeks. Some cuneiform tablets were recovered with the numbers $\{1, 24, 51, 10\}$ written upon the diagonal of a square. Interpreting this in the native base-60 of the Babylonians, we get this:

$$
\sqrt{2} \approx 1 + \frac{24}{60} + \frac{51}{60^2} + \frac{10}{60^3} = 1.41421296296\cdots\\
$$

Not to be outdone, the sages of the Vedas gave the below approximation for $\sqrt{2}$ in the Sulba Sutras, which were texts describing the required shape and geometry of yajnakundas (sacrificial altars):

$$
\sqrt{2} \approx 1 + \frac13 + \frac1{3 \cdot 4} - \frac1{3 \cdot 4 \cdot 34} = 1.41421568627\cdots\\
$$

For comparison, the true value of $\sqrt{2}$ is around $1.41421356237\cdots$. Pretty damn close!

There is some debate over how these approximations were arrived at, and there is a nice article titled ["Square Root of 2 in Babylonian Mathematics and the Sulbasutras"](https://bhaskarkamble.substack.com/p/fractions-and-sexagesimals) by a certain Bhaskar Kamble which goes into depth over several questions related to the history of $\sqrt{2}$ approximations and how they may have been derived. Very interesting read. He discusses something known as the square-root algorithm (sometimes called the Babylonian Method) and posits that it may have originated in India instead. I'm unsure, but the square-root algorithm is beautiful nonetheless, and I'd like to share it.

In fact, let's learn the square-root algorithm in this very next question using a practical example!

---

### Demonstration

Approximate $\sqrt{10 005}$ using the square-root algorithm.

**Intuition:**

I remember drilling through a painful long-division method to calculate square-roots. It was painful and complicated and I hated it. This square-root algorithm, on the other hand? I learnt a version of it from a video by Vsauce.

Let's say we want to find the square root of $10 005$. $\sqrt{10 005}$ has the unique property that $\sqrt{10 005} = \frac{10 005}{\sqrt{10 005}}$. So,

$$
\sqrt{10 005} = \frac12 \left( \sqrt{10 005} + \frac{10 005}{\sqrt{10 005}} \right)
$$

This gives us a clear algorithm to approximate $\sqrt{N}$:

- Guess that $\sqrt{N} \approx x_0$
- Calculate $x_1 = \frac12 \left( x_0 + \frac{N}{x_0} \right)$
- Calculate $x_2 = \frac12 \left( x_1 + \frac{N}{x_1} \right)$
- And so on until you get your desired accuracy.

And oftentimes, if you choose $x_0$ to be the closest square to $N$, then even $x_1$ is enough for most practical applications.

Why does this work? Well, if $x_n$ is an overestimate of $\sqrt{N}$, then $\frac{N}{x_n}$ will be an underestimate for this, and vice versa. So with each iteration, we inch closer and closer to the actual answer.

Of course, a rigorous proof of this method is quite involved and requires invoking such things as the Monotone Convergence Theorem and others. A proper handling of this can be found in this video by Wrath of Math: [The One they Didn't Teach You in School](https://www.youtube.com/watch?v=8O_By1ppMg8)

Finding square-roots with the traditional long-division method is long, boring and cumbersome. This method, on the other hand? I used it many times in exams, especially because my younger brother borrowed my scientific calculator, but ended up getting robbed of it by some guy in in his college.

**Demonstration:**

Note that $100^2 = 10 000$. Hence, set $x_0 = 100$.

$$
x_1 =  \frac12 \left( 100 + \frac{10 005}{100} \right) = \frac{4001}{40}\\
\implies \sqrt{10 005} \approx 100.025
\tag*{$\mathfrak{Q.E.D.}$}
$$

**Fun Fact:**

And if you aren't satisfied? No worries! You simply plug in your output back into the process and repeat again, and your approximations will get progressively better.

As mentioned, the aforementioned Bhaskar Kamble argues that the nature of how the approximation of $\sqrt{2}$  is expressed in the Sulba Sutras indicates that this method, or some method close to it, was probably known to Baudhayana, Apastambha, and other Vedic sages. And for this, I'll just quote the man himself:

>The above code shows the first five “digits” in sexagesimal of the computer generated square root of two, and one can see that the first four (1, 24, 51, and 10) are identical to the Babylonian value. To use the equality of the sexagesimal “digits” of the length of the diagonal with the “digits” obtained from the square root algorithm is therefore like a trick to justify the claim that the square root algorithm was used. Incidentally, this reminds me of a similar trick that was doing the rounds of the internet and social media a few years back. I saw it in the year 2019 and it went like [2].
>
> "It’s amazing: this year is special. It happens only once every 1,000 years. This year your age + your year of birth, every individual is = 2019. For example, you are 55 years old and you were born in 1964, which adds up to 2019. Very strange, even the Chinese and foreign masters can not explain. Please calculate and see if the answer is 2019. It’s a thousand-year wait! Good shot! Go to the circle of friends, let everybody calculate it!"
>
> So the sexagesimal representation does not tell us anything. What does give a clue however is the fractional representation. In fractional representation of the Babylonian value is 30547 / 21600. If we start from 3/2 as the initial guess and if we encounter at some point this fraction, then the possibility that the square root algorithm was used becomes a strong one. Let us see if this is the case, starting with, as Neugebauer does, 3/2 as the initial guess:
>
> 1) r1 = 3/2
>
> 2) r2 = (1/2)(3/2 + 4/3) = 17/12
>
> 3) r3 = (1/2)(17/12 + 24/17) = 577/408
>
> 4) r4 = 1/2(577/408 + 816/577) = 665857/470832
>
> Etc.
>
> Nowhere do we encounter the fraction 30547 / 21600 in the above. So on what basis is it claimed that the Babylonians used the square root algorithm for finding the length of the diagonal?
>
> Now we come to the Sulba value of 1 + 1/3 + 1/(3·4) – 1/(3·4·34).
>
> 1) The first two terms: 1 + 1/3 = 4/3
>
> 2) The first three terms: 1 + 1/3 + 1/(3·4) = 17/12
>
> 3) The first four terms: 1 + 1/3 + 1/(3·4) – 1/(3·4·34) = 577 / 408.
>
> We did not encounter the Babylonian 30547 / 21600. But surprise, surprise, at all the three steps the fractions match with the Sulba value. This is obviously a much stronger indication that the square root algorithm was used for deriving the Sulbasutra value instead of the Babylonian value. And if we reduce our standards to those of Neugebauer, that is, compute the sexagesimal representation of the Sulba value and check if they match with the Babylonian value, what do we find? Unsurprisingly, the same sexagesimal “digits” as those of YBC 7289.

I'm not knowledgeable enough in history to be able to verify all of this, but this feels very convincing to me. Regardless of who found it, whether they are sages from India or sages from Babylon, it is definitely a very useful and powerful algorithm, so much so that computers use it even today.

[[i feel like... nevermind]]