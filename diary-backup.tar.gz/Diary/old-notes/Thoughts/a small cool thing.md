---
title: a small cool thing
updated: 2026-01-07 18:31:43Z
created: 2025-12-27 13:47:24Z
latitude: 17.38504400
longitude: 78.48667100
altitude: 0.0000
---

Hello future wifey, I hope you're doing well.

I notice that I have been rushing entries recently, you know? I actually deleted two entries because they felt rushed and like I was trying to meet a daily quota rather than enjoying mathematics. Indeed, depression is doing what depression does: it is making meaningful, joyful things feel like insurmountable burdens, like obligations rather than things that should be joyous.

Aside from that, I've been struggling with anxiety recently regarding subject credits, regarding capstone project reviews, regarding code, regarding all sorts of things.

My expectation is probably that I will vibe code my capstone project over the span of a few days, but right now I don't want to think about this. I have a clear deadline, and I have a clear idea of what I need to do. I'll try to vibe code this and finish this off as soon as possible. I'm not gonna waste mental energy on a project I don't even care about. I'll just let AI do the grunt work and focus on architecture and save energy for projects where I actually care about the end result. In those cases, I use AI as a teacher rather than something that does grunt work for me.

In times like this, some writing in this diary makes me feel grounded. So I'd like to share a small problem I found that is... trivial? I don't know. And I'd like to do some simple calculations as well; when you are distressed, doing simple arithmetic is surprisingly grounding and calming. I guess it is an inherent quality of simple arithmetic. It is elementary, deterministic, it rewards patience, and it rewards focus.

Anyway, onto the problem.

---

I'll actually begin with some context. I was in an anxiety spiral today, and I decided to calm myself down by watching a video on a famous unsolved problem called Goldbach's Conjecture. It was proposed by Christian Goldbach in a letter to the great Leonhard Euler, and in a reply letter, Euler wrote this:

> *"Dass aber ein jeder numerus par eine summa duorum primorum sey, halte ich für ein ganz gewisses theorema, ungeachtet ich dasselbe nicht demonstriren kann."*
>
> Translation, according to online sources: "That every even number is the sum of two primes: I hold this to be a completely certain truth... looking past the fact that I cannot myself prove it."

Euler is, of course, woefully incorrect, as $2$ cannot be expressed as the sum of two primes. Hence, Goldbach's Conjecture is trivially false. $\mathfrak{Q.E.D.}$, give me $\$1 000 000$, Clay Mathematical Institute. /j

Of course, Goldbach's Conjecture has since been refined to avoid this glaring edge-case to be the following:

> Every even integer greater than or equal to $4$ can be written as the sum of two primes.

This modified version is a real chestnut. We've verified it for all natural numbers less than $4 \times 10^{18}$, but we have no definitive proof. So many covet to solve it, and who knows? Maybe you hold the insight necessary to prove it. Mathematics has always been democratic: your credentials don't matter so long as your proof is correct.

At any rate, I decided to ask: "Can you write every prime as the sum of two composites?" And after playing around for a bit, I managed to prove something nice.

---

**Theorem:** Every prime $p > 11$ can be written as the sum of two composite numbers.

You can try to prove it if you wish: the proof is surprisingly nice. If not, keep reading and I'll walk you through.

**Proof:**

Let $p$ be a prime greater than $11$. Thus $p = 9 + (p - 9)$.

Why $9$ specifically? Because of the nature of primes greater than $2$. All primes greater than $2$ are odd, so $p = 2n + 1$. But $2n + 1$ isn't the only way to write an odd number. It can be $2a + 3$, $2b + 5$, $2c + 7$, $2d + 9$, ...: basically, $2r + \text{odd number}$ is always odd. We chose $9$ as it is both odd and composite, as $9 = 3 \cdot 3$.

OK. Now notice $p - 9$. It is an odd number minus an odd number, which is always an even number. But at the same time, since $p > 11$, $p - 9 > 2$. Since $p - 9$ is even and greater than $2$, it too is composite as it has $2$ as a factor.

Therefore, every prime number greater than 11 can be written as the sum of two composite numbers. Or, to write it in mathematical hieroglyphs...

$$
p = a + b \quad \forall p > 11 \land a,b \notin \mathbb{P} \cup \{1\}
\tag*{$\mathfrak{Q.E.D.}$}
$$

---

Nice. A cute and simple proof.

Then, a natural question arises: for a given prime $p$, how many ways are there? Let us calculate a few by hand.

**1. $p = 13$**

Let us see:

- $1 + 12$ doesn't work as $1$ is neither prime nor composite.
- $2 + 11$ doesn't work as both are prime.
- $3 + 10$ doesn't work as $3$ is prime.
- $4 + 9$ works! Both $4$ and $9$ are composite.
- $5 + 8$ doesn't work as $5$ is prime.
- $6 + 7$ doesn't work as $7$ is prime.

We needn't check any more as the rest of the possibilities are just mirror images. There is only one way to write $13$ as the sum of two composite numbers. Indeed, for a prime $p$, we need to check $\frac{p - 1}{2}$ pairs. Why? Well, if you include $0$, then you will have a whole bunch of pairs, $14$ in all: $(0, 13), (1, 12), \cdots, (12, 1), (13, 0)$. But note: half of them are repeats, meaning there are only $7$ unique pairs: $(0, 13), (1, 12), \cdots, (5, 8), (6,7)$. Removing the artificial $(0, 13)$ pair gives us $6$ pairs to check. In general for a prime $p$, you need to check $\frac{p + 1}{2} - 1 = \frac{p - 1}{2}$ pairs.

**2. $p = 17$**

We need to check $\frac{17 - 1}{2} = 8$ pairs: $(1, 16), (2, 15), \cdots, (8, 9)$. Of these, only one works: $17 = 8 + 9$.

**3. $p = 19$**

This has two ways: $19 = 4 + 15 = 9 + 10$

And you can keep writing ways on and on. Very relaxing, I gotta say.

(And that ends all the legacy Joplin notes, folks!)

[[About Me]]